#ifndef LISTAFILACOLUMNA_H
#define LISTAFILACOLUMNA_H
#include <EsperaColumna.h>


class ListaFilaColumna
{
    public:
        ListaFilaColumna();
        virtual ~ListaFilaColumna();

        EsperaColumna *primero=NULL;
        EsperaColumna *ultimo=NULL;
        int id_actual = 0 ;

        void AgregarAsientos(EsperaColumna *fila);
        int No_DePersonasOcupandoLugares();

    protected:
    private:
};

#endif // LISTAFILACOLUMNA_H

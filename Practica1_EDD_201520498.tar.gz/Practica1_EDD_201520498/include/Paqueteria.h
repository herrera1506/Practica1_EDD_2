#ifndef PAQUETERIA_H
#define PAQUETERIA_H
#include <iostream>
#include <Paqueteria.h>
using namespace std;

class Paqueteria
{
    public:
        Paqueteria();
        //string nombre, string tipo, string ubicacion, string informacion, int entrandos
        Paqueteria(int id, string Nombre, string TipoPaquete,string Asunto, int Esta);
        virtual ~Paqueteria();


        Paqueteria *Siguiente=NULL;
        Paqueteria *Anterior=NULL;

        int id=0;
        string Nombre;
        string TipoPaquete;
        string Asunto;

         bool EnRevision = false;
         bool Ingresando = false;


    protected:
    private:
};

#endif // PAQUETERIA_H

#ifndef EQUIPAJE_H
#define EQUIPAJE_H
#include <Equipaje.h>
#include <iostream>

using namespace std;

class Equipaje
{
    public:
        Equipaje();
        Equipaje(int Id, string Ubicacion, string TipodeEquipaje, string AsuntodeEquipaje, int Esta);
        virtual ~Equipaje();

        int Id=0;
        int Esta=0;
        string Ubicacion="";
        string TipodeEquipaje="";
        string AsuntodeEquipaje="";

        Equipaje *Siguiente=NULL;
        Equipaje *Anterior=NULL;

        bool EstaEnRevision=false;
        bool Ingresando=false;


    protected:
    private:
};

#endif // EQUIPAJE_H

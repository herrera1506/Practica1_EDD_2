#ifndef SALADEESPERA_H
#define SALADEESPERA_H
#include <Clientes.h>
#include <ListaCliente.h>


class SaladeEspera
{
    public:
        SaladeEspera();
        virtual ~SaladeEspera();

        int Id=0;
        Clientes *Cola_Clientes=NULL;
        SaladeEspera * siguiente=NULL;
        SaladeEspera * anterior=NULL;
    protected:
    private:
};

#endif // SALADEESPERA_H

#ifndef GRAFICAR_H
#define GRAFICAR_H
#include <Vuelos.h>
#include <ListaVuelos.h>
#include <iostream>
#include <Clientes.h>
#include <Empleados.h>
#include <string>
#include <ListaCliente.h>
#include <PilaEmpleado.h>
#include <RandomClientes.h>
#include <Paqueteria.h>
#include <RandomPaquetes.h>
#include <ListaPaqueteria.h>
#include <Equipaje.h>
#include <ListaEquipaje.h>
#include <RandomEquipaje.h>
#include <Vuelos.h>
#include <ListaVuelos.h>
#include <RamdonVuelos.h>
#include <ListaEmpleado.h>
#include <RandomEmpleado.h>
#include <Empleados.h>
#include <stdlib.h>
#include <time.h>
#include <ListaEmpleado.h>
#include <Hangares.h>
#include <Estaciones.h>
#include <ListasEstaciones.h>
#include <ListaHangares.h>
#include <Restaurantes.h>
#include <ListaRestaurantes.h>
#include <EsperaColumna.h>
#include <ListaFilaColumna.h>
#include <ListaRestaurantes.h>
#include <SaladeEspera.h>
#include <Graficar.h>



class Graficar
{
    public:
        Graficar();
        virtual ~Graficar();
//        ListaVuelos Lista_Vueloss = new ListaVuelos();

        void GraficarVuelos(Vuelos* vuelo);


        //ListasEstaciones *LEstaciones = new ListasEstaciones();
         ListasEstaciones *LEstaciones ;
        ListaVuelos *LVuelos = new ListaVuelos();
        ListaCliente *LClientes = new ListaCliente();
        ListaEquipaje *LEquipaje= new ListaEquipaje();
        ListaPaqueteria *LPaquetes = new ListaPaqueteria();
        ListaEmpleado *LEmpleados = new ListaEmpleado();

        string GrafoCompleto  = "";
        string col = "";
        string col1 = "";

        string Gclientes= "";
        string GVuelo = "";

        string GSim="";

        void CrearGrafo();
        void AgregarListaEstacion();//Grafo del cual nacen todos los demas
        void AAtencion(Estaciones *Estacion);//para cada estacion de atencion

        void AColaEsperaAtencion(string col);//adquiriendo cola espera atencion
        void ASeguridad(Estaciones *Estacion);// para cada estacion seguridad
        void AColaSeguridad(string col1);//adquiriendo cola espera seguridad
        void ARestaurantes();//adquiere Restaurantes
        void ARestaurant(Restaurantes *Restaurantesss);

        void SalaDeEspera();//para sala de espera
        void hanga();

        void Dot();

        void DotClientes();
        void DotVuelos();
        void DotSimulaciones();

        void simula1();
        void simula2();
        void simula3();
        void simula4();
        void simula5();






    protected:
    private:
};

#endif // GRAFICAR_H

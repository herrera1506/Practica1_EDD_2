#ifndef HANGARES_H
#define HANGARES_H

#include "string"
#include <Vuelos.h>


using namespace std;
class Hangares
{
    public:
        Hangares();
        Hangares(int Id, string Nombre);
        virtual ~Hangares();

        int Id=0;;
        string Nombre="";
        Vuelos *Vueloss=NULL;
        Hangares *siguiente=NULL;
        bool HangarCasiLleno = false;

    protected:
    private:
};

#endif // HANGARES_H

#ifndef LISTACLIENTE_H
#define LISTACLIENTE_H
#include <string>
#include <stdio.h>
#include <iostream>
#include <Clientes.h>

using namespace std;
class ListaCliente
{
    public:
        ListaCliente();
        virtual ~ListaCliente();

            int Id_Actual=0;

            Clientes *primero=NULL;
            Clientes *ultimo=NULL;

        //void insertar_dato(string nombre, string tipo_cliente, string estado, int edad, string informacion, string ubicacion, string genero);
        void AgregarDatos(string Nombre, string RagoEdad, int Edad, string Ubicacion, string TipoCliente, string Informacion, string Genero);
        void MostrarDatos();


        void AgregarDatos2(Clientes *Nuevo);
        void MostrarDatos2(Clientes *Llamado);


        int Contar();

    protected:
    private:
};

#endif // LISTACLIENTE_H

#ifndef RAMDONVUELOS_H
#define RAMDONVUELOS_H
#include <Vuelos.h>


class RamdonVuelos
{
    public:
        RamdonVuelos();
        virtual ~RamdonVuelos();
        Vuelos *Agregar_Vuelos(int dato);
    protected:
    private:
};

#endif // RAMDONVUELOS_H

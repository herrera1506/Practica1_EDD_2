#ifndef LISTAHANGARES_H
#define LISTAHANGARES_H
#include <Hangares.h>


class ListaHangares
{
    public:
        ListaHangares();
        virtual ~ListaHangares();

         Hangares *primero=NULL;
         Hangares *ultimo=NULL;

        int id_actual = 0;

        void AgregarHangarares(Hangares *Hangares);
        bool AgregarVuelo(Vuelos *vuelo);
        void mostrar_datos();

    protected:
    private:
};

#endif // LISTAHANGARES_H

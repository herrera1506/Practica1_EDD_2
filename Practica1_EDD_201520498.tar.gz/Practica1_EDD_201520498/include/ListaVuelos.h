#ifndef LISTAVUELOS_H
#define LISTAVUELOS_H
#include <Vuelos.h>


class ListaVuelos
{
    public:
        ListaVuelos();
        virtual ~ListaVuelos();
        Vuelos *primero =NULL;
        Vuelos *ultimo= NULL;

        int id_actual=0;

        void Agregar_Vuelos(Vuelos * Vuelos);
        void mostrar_datos(Vuelos *Vue);
        int Contar();


    protected:
    private:
};

#endif // LISTAVUELOS_H

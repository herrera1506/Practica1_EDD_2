#ifndef COLAESPERAATENCIONALCLIENTE_H
#define COLAESPERAATENCIONALCLIENTE_H
#include <Clientes.h>
using namespace std;

class ColaEsperaAtencionalCliente
{
    public:
        ColaEsperaAtencionalCliente();
        virtual ~ColaEsperaAtencionalCliente();

        Clientes *primero=NULL;
        Clientes *ultimo=NULL;
        int id_actual =0;
        int actual = 0;

        void AgregarAlInicio(Clientes *cliente);
        void AgregarNormal(Clientes *cliente);
        int CantidaddePersona();

        Clientes* EnviarSiguiente();
        void push_();


    protected:
    private:
};

#endif // COLAESPERAATENCIONALCLIENTE_H

#ifndef COLAESPERAATENCIONALCLIENTE_H
#define COLAESPERAATENCIONALCLIENTE_H
#include <Clientes.h>
using namespace std;

class ColaEsperaAtencionalCliente
{
    public:
        ColaEsperaAtencionalCliente();
        virtual ~ColaEsperaAtencionalCliente();

            int Id=0;
            string Nombre="";
            int No_Personas_Esperas;
            Clientes * primero=NULL;
            Clientes * ultimo=NULL;

        void AgregaralInicio(Clientes *Cliente);
        void AgregarClientesasala(Clientes *Cliente);



    protected:
    private:
};

#endif // COLAESPERAATENCIONALCLIENTE_H

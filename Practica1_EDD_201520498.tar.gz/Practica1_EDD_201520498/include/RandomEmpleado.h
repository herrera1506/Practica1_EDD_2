#ifndef RANDOMEMPLEADO_H
#define RANDOMEMPLEADO_H
#include <PilaEmpleado.h>
#include <ListaEmpleado.h>


class RandomEmpleado
{
    public:
        RandomEmpleado();
        virtual ~RandomEmpleado();
        Empleados* AgregarEmpleadoRandom(int dato);


    protected:
    private:
};

#endif // RANDOMEMPLEADO_H

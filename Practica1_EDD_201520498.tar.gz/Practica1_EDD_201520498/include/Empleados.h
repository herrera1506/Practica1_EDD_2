#ifndef EMPLEADOS_H
#define EMPLEADOS_H
#include <string>
using namespace std;
class Empleados
{
    public:
        Empleados();
        Empleados(int Id, int Turno, string Nombre, string Informacion, string Empleado_Ubicacion);
        virtual ~Empleados();

        Empleados *Siguiente=NULL;
        Empleados *Anterior=NULL;
        int Id=0;
        int Turno=0;
        int Tipo=0;
        string Nombre="";
        string Informacion="";
        string Empleado_Ubicacion="";

        bool EstaenTurno = false;
        bool EmpleadoenSeguridad = false;
        bool EmpleadoenAtencion = false;

    protected:
    private:

};

#endif // EMPLEADOS_H

#ifndef RESTAURANTES_H
#define RESTAURANTES_H
#include <ColaEsperaAtencionalCliente.h>


class Restaurantes
{
    public:
        Restaurantes();
        Restaurantes(int Capacidad);
        virtual ~Restaurantes();


        Restaurantes *anterior=NULL;
        Restaurantes *siguiente=NULL;
        int id=0;
        ColaEsperaAtencionalCliente *cliente=NULL;
        int capacidad = 0;
        bool RestaLleno = false;

    protected:
    private:
};

#endif // RESTAURANTES_H

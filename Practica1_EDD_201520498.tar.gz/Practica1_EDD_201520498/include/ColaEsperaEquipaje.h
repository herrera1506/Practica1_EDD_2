#ifndef COLAESPERAEQUIPAJE_H
#define COLAESPERAEQUIPAJE_H
#include <Equipaje.h>
#include <Estaciones.h>

class ColaEsperaEquipaje
{
    public:
        ColaEsperaEquipaje();
        virtual ~ColaEsperaEquipaje();
        Equipaje *primero=NULL;
        Equipaje *ultimo=NULL;
        int id_actual;
        void AgregarEquipajeSala (Equipaje * Equipaje);
        bool Contiene();
        void Push(string NombresEstacion);
        void SacarEquipaje();

    protected:
    private:
};

#endif // COLAESPERAEQUIPAJE_H

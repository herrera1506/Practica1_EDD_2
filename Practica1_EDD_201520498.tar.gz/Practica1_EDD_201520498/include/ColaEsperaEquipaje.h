#ifndef COLAESPERAEQUIPAJE_H
#define COLAESPERAEQUIPAJE_H
#include <Equipaje.h>

class ColaEsperaEquipaje
{
    public:
        ColaEsperaEquipaje();
        virtual ~ColaEsperaEquipaje();
        Equipaje *primero=NULL;
        Equipaje *ultimo=NULL;

        void AgregarEquipajeSala (Equipaje * Equipaje);

    protected:
    private:
};

#endif // COLAESPERAEQUIPAJE_H

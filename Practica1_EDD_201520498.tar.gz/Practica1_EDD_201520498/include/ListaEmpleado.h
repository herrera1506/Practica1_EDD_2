#ifndef LISTAEMPLEADO_H
#define LISTAEMPLEADO_H
#include <Empleados.h>

class ListaEmpleado
{
    public:
        ListaEmpleado();
        virtual ~ListaEmpleado();
        int id_actual=0;

        Empleados *primero =NULL;
        Empleados *ultimo=NULL;

        void AgregarEmpleados(Empleados *Empleados);
        void Mostrar_Datos(Empleados *Empleados);
        int Contador();

    protected:
    private:
};

#endif // LISTAEMPLEADO_H

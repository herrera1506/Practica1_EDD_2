#ifndef ESPERACOLUMNA_H
#define ESPERACOLUMNA_H
#include <ListaSaladeEspera.h>


class EsperaColumna
{
    public:
        EsperaColumna();
        virtual ~EsperaColumna();

        EsperaColumna *siguiente;
        int id=0;
        ListaSaladeEspera *fila;
        bool EnUso = false;

    protected:
    private:
};

#endif // ESPERACOLUMNA_H

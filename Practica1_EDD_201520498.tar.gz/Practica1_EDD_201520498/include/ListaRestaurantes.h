#ifndef LISTARESTAURANTES_H
#define LISTARESTAURANTES_H
#include <Restaurantes.h>


class ListaRestaurantes
{
    public:
        ListaRestaurantes();
        virtual ~ListaRestaurantes();

        int id_actual= 0;

        Restaurantes *primero=NULL;
        Restaurantes *ultimo=NULL;

        void Agregar_Restaurantes(Restaurantes *Resta);
        int CantidadenRestaurante();

    protected:
    private:
};

#endif // LISTARESTAURANTES_H

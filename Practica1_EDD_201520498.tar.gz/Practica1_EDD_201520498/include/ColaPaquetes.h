#ifndef COLAPAQUETES_H
#define COLAPAQUETES_H
#include <Paqueteria.h>


class ColaPaquetes
{
    public:
        ColaPaquetes();
        virtual ~ColaPaquetes();

        Paqueteria *primero;
        Paqueteria *ultimo;
        int id_actual=0;
        void AgregarColaPaquetes(Paqueteria *Paquetes);
        void PUSH (string NombreEstacion);



    protected:
    private:
};

#endif // COLAPAQUETES_H

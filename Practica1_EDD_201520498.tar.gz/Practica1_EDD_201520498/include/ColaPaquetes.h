#ifndef COLAPAQUETES_H
#define COLAPAQUETES_H
#include <Paqueteria.h>


class ColaPaquetes
{
    public:
        ColaPaquetes();
        virtual ~ColaPaquetes();

        Paqueteria *primero;
        Paqueteria *ultimo;

        void AgregarColaEquipaje(Paqueteria *Paquetes);


    protected:
    private:
};

#endif // COLAPAQUETES_H

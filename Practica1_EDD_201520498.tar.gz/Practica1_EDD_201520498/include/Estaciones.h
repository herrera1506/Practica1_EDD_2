#ifndef ESTACIONES_H
#define ESTACIONES_H
#include <iostream>
#include <Estaciones.h>
#include <Empleados.h>
#include <ListaCliente.h>


using namespace std;
class Estaciones
{
    public:
        Estaciones();
        Estaciones(int id, string Nombre, string Informacion, int No_Estacion);
        virtual ~Estaciones();


        Estaciones *anterior=NULL;
        Estaciones *siguiente=NULL;

        int id=0;
        string Nombre="";
        string Informacion="";
        int No_Estacion=0;

        Empleados *CargoEmpleado=NULL;
        ListaCliente *ClientesenCola=NULL;

        bool Atencion_alCliente = false;
        bool seguridad_Cliente_inicio = false;
        bool seguridad_Cliente_final = false;

    protected:
    private:
};

#endif // ESTACIONES_H

#ifndef ESTACIONES_H
#define ESTACIONES_H
#include <iostream>
#include <Estaciones.h>
#include <Empleados.h>
#include <ListaCliente.h>


using namespace std;
class Estaciones
{
    public:
        Estaciones();
        Estaciones(int id, string Nombre, string Informacion, int No_Estacion);
        virtual ~Estaciones();


        Estaciones *anterior=NULL;
        Estaciones *siguiente=NULL;

        int id=0;
        string Nombre="";
        string Informacion="";
        int No_Estacion=0;

        Empleados *CargoEmpleado=NULL;
        Clientes *ClientesEnEstaciones=NULL;

        bool AtencionAlCliente1 = false;
        bool SeguridadCliente1 = false;
        bool SeguridadCliente2=false;
        bool TieneEmpleados1 = false;

    protected:
    private:
};

#endif // ESTACIONES_H

#ifndef CLIENTES_H
#define CLIENTES_H
#include <iostream>
#include <string>

using namespace std;
class Clientes
{
    public:
        Clientes();
        Clientes(string Nombre, int Ordenamiento, int Edad, string Ubicacion, string TipoCliente, string Informacion, string Genero);
        Clientes(string Nombre, int Ordenamiento, int Edad, string Ubicacion, string TipoCliente, string Informacion, string Genero, int boleto);
        virtual ~Clientes();

        Clientes *Siguiente=NULL;
        Clientes *Anterior=NULL;

        int id;
        int Edad;
        int Tiempo_Vuelo;
        int Ordenamiento;
        string Nombre;
        string TipoCliente;
        string Informacion;
        string Ubicacion;
        string Genero;


        bool Boleto = false;
        bool Cliente_en_Atencionalcliente = false;
        bool Cliente_en_Seguridad =false;


        bool mayor_edad = false;
        bool menor_edad = false;
        bool terecera_edad = false;
        bool discapacitado_ = false;
        bool embarazada_ = false;


    protected:
    private:


};


#endif // CLIENTES_H

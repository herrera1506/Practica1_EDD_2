#ifndef VUELOS_H
#define VUELOS_H
#include <iostream>
#include <ListaCliente.h>
#include <ListaEquipaje.h>
#include <ListaPaqueteria.h>


using namespace std;

class Vuelos
{
    public:
        Vuelos();
        Vuelos(int Id, string Nombre, int Cantidad_Pasajeros, int Cantidad_Equipajes, int Cantidad_Paquetes, string Situacion_Vuelo);
        virtual ~Vuelos();


        Vuelos *Anterior=NULL;
        Vuelos *Siguiente=NULL;

        int id;
        string nombre;
        ListaCliente *clientes_Volando;
        ListaPaqueteria *Paquetes_Volando;
        ListaEquipaje *Equipaje_Volando;
        int Cantidad_Pasajeros;
        int Cantidad_Equipajes;
        int Cantidad_Paquetes;
        //string Situacionnnnn;
        string Situacion_Vuelo ;


    protected:
    private:
};
#endif // VUELOS_H

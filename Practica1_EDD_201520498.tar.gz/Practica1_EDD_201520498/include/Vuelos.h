#ifndef VUELOS_H
#define VUELOS_H
#include <iostream>
#include <ListaCliente.h>
#include <ListaEquipaje.h>
#include <ListaPaqueteria.h>


using namespace std;

class Vuelos
{
    public:
        Vuelos();
        Vuelos(int Id, string Nombre, int Cantidad_Pasajeros, int Cantidad_Equipajes, int Cantidad_Paquetes, int Entrando);
        virtual ~Vuelos();


        Vuelos *Anterior=NULL;
        Vuelos *Siguiente=NULL;

        int id;
        string nombre;
        string Informacion;
        ListaCliente *ClientesVolando;
        ListaPaqueteria *PaquetesVolando;
        ListaEquipaje *EquipajeVolando;
        int Cantidad_Pasajeros=0;
        int Cantidad_Equipajes=0;
        int Cantidad_Paquetes=0;
        //string Situacionnnnn;
        bool SituacionVuelo=false;


    protected:
    private:
};
#endif // VUELOS_H

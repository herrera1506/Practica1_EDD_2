#ifndef LISTASESTACIONES_H
#define LISTASESTACIONES_H
#include <Estaciones.h>
#include <PilaEmpleado.h>
#include <RandomClientes.h>
#include <Paqueteria.h>
#include <RandomPaquetes.h>
#include <ListaPaqueteria.h>
#include <Equipaje.h>
#include <ListaEquipaje.h>
#include <RandomEquipaje.h>
#include <Vuelos.h>
#include <ListaVuelos.h>
#include <RamdonVuelos.h>
#include <ListaEmpleado.h>
#include <RandomEmpleado.h>
#include <Empleados.h>
#include <stdlib.h>
#include <time.h>
#include <ListaEmpleado.h>
#include <Hangares.h>
#include <Estaciones.h>
#include <ListasEstaciones.h>
#include <ListaHangares.h>
#include <Restaurantes.h>
#include <ListaRestaurantes.h>
#include <EsperaColumna.h>
#include <ListaFilaColumna.h>


class ListasEstaciones
{
    public:
        ListasEstaciones();
        virtual ~ListasEstaciones();
         Estaciones *primero=NULL;
         Estaciones *ultimo=NULL;

        ListaRestaurantes *restaurante = new ListaRestaurantes();
        ListaFilaColumna*SalaEspera = new ListaFilaColumna();

        ColaEsperaAtencionalCliente *Colo_Espera = new ColaEsperaAtencionalCliente();
        ColaEsperaEquipaje *ColaEquipaje= new ColaEsperaEquipaje();
        ColaPaquetes * ColaPaquetes =new ColaPaquetes();

        ColaEsperaAtencionalCliente * ColaEsperaAtencionCliente =new ColaEsperaAtencionalCliente();

        int id_actual = 0;

        bool AsignacionestacionAtencion(Clientes *cliente);//ya

        bool AsignacionesestacionSeguridad(Clientes *cliente);//ya

        bool AsignacionestacionSeguridad1(Equipaje *cliente);//ya

        bool AsignacionestacionSeguridad2(Paqueteria *cliente);//ya

        void EliminarAtencion();

        void EliminarAtenciones(Estaciones * Esta);

        Clientes* TraerdeColaDeEspera();

        void ActualizarEquipaje (Estaciones * Esta);

        void ActualizarPaquetes(Estaciones *Esta);


        void EliminarSeguridad1();//ya
        void EliminarSeguridad2();//ya
        void EliminarSeguridad3();
        void EliminarSeguridadConPuntero(Estaciones *estacion);//ya

        void EnviarARestaurantes(ListaRestaurantes *Restaurante, Clientes * clientes);//ya
        void EnviarASaladeEspera(ListaFilaColumna *ColaEspera, Clientes *clientes);//ya

        void AgregarEstacion(Estaciones *estacion);//ya
        void mostrar_datos();//ya
        bool AgregandoEmpleados(Empleados *empleado);//ya

        void ActualizarEmpleados();



    protected:
    private:
};

#endif // LISTASESTACIONES_H

#ifndef LISTASESTACIONES_H
#define LISTASESTACIONES_H
#include <Estaciones.h>

class ListasEstaciones
{
    public:
        ListasEstaciones();
        virtual ~ListasEstaciones();
         Estaciones *primero=NULL;
         Estaciones *ultimo=NULL;
        int id_actual = 0;
        void AgregarEstaciones(Estaciones *Estacion);
        void mostrar_datos();
    protected:
    private:
};

#endif // LISTASESTACIONES_H

#ifndef LISTASESTACIONES_H
#define LISTASESTACIONES_H
#include <Estaciones.h>
#include <PilaEmpleado.h>
#include <RandomClientes.h>
#include <Paqueteria.h>
#include <RandomPaquetes.h>
#include <ListaPaqueteria.h>
#include <Equipaje.h>
#include <ListaEquipaje.h>
#include <RandomEquipaje.h>
#include <Vuelos.h>
#include <ListaVuelos.h>
#include <RamdonVuelos.h>
#include <ListaEmpleado.h>
#include <RandomEmpleado.h>
#include <Empleados.h>
#include <stdlib.h>
#include <time.h>
#include <ListaEmpleado.h>
#include <Hangares.h>
#include <Estaciones.h>
#include <ListasEstaciones.h>
#include <ListaHangares.h>
#include <Restaurantes.h>
#include <ListaRestaurantes.h>
#include <EsperaColumna.h>
#include <ListaFilaColumna.h>
#include <ColaEsperaEquipaje.h>
#include <ColaPaquetes.h>


class ListasEstaciones
{
    public:
        ListasEstaciones();
        virtual ~ListasEstaciones();

         Estaciones *primero=NULL;
         Estaciones *ultimo=NULL;

        ListaRestaurantes *CrearResta = new ListaRestaurantes();
        ListaFilaColumna*SalaEspera = new ListaFilaColumna();
        ColaEsperaAtencionalCliente *Colo_Espera = new ColaEsperaAtencionalCliente();
        ColaEsperaEquipaje *ColaEquipaje = new ColaEsperaEquipaje();
        ColaPaquetes *ColaPaquetess =new ColaPaquetes();

        ListaHangares *hangares = new ListaHangares();
        ColaEsperaAtencionalCliente *ColaEsperaAtencionC =new ColaEsperaAtencionalCliente();

        int id_actual = 0;
        int PersonasSalieronAlAvion =0;
        int AvionesQueDespegaron=0;
        int PerdieronSuvuelodeRestaurantes =0;
        int PerdieronSuvuelodeSaladeEspera=0;
        int PersonasEnSalaEspera=0;
        int PesonasRestau = 0;

        bool AsignacionestacionAtencion(Clientes *cliente);//ya
        bool AsignacionesestacionSeguridad(Clientes *cliente);//ya
        bool AsignacionestacionSeguridad1(Equipaje *cliente);//ya
        bool AsignacionestacionSeguridad2(Paqueteria *cliente);//ya

        void SalidadelAvion(Clientes *Clientes);

        void ReduceEltiempodeVuelo(Restaurantes *restaurante);
        void ReducirenRestaurantes();

        void ActualizarEquipaje (Estaciones * Esta);
        void ActualizarPaquetes(Estaciones *Esta);

        void EliminarSeguridad2();
        void EliminarSeguridad3();

        void AgregarEstacion(Estaciones *estacion);
        void mostrar_datos();

        bool AgregandoEmpleados(Empleados *empleado);
        void ActualizarEmpleados();


      //esta
        int EncontrarE(); //Econttrar1Empleados
        //Esta
        //ActualizarEstacionAclitente
        void ActualizarEA(); ////
        //AdquirirEstadoAtencion
        void AdquirirEA(); // adquirimos si posee cliente y empleado
        Clientes* NuevoclienteAtencion();// mandamos a llamar un nuevo cliente;
        //ActualizarEstacion
        void ActualizarE(Clientes *cliente, Estaciones *estacion);
        //EnviarClienteaSeguridad
        void EnviarClienteAS(Clientes *cliente);
        Estaciones* PreguntarEstadoSeguridad();// mandamos a preguntar si hay una estacion vacia


          //[Seguridad] -- SEGURIDAD
          //ActualizarEstacionSegurirar
        void ActualizarES();
        //AdquirirEstadoSeguridad
        void AdquirirEstadoSeguridad(); // adquirimos si posee cliente y empleado [igual que en atencion]
        //ActualizarEstacion1
        void ActualizarE1(Clientes *cliente,Estaciones *estacion);
        Clientes* NuevoClienteSeguridad();
        //EnviarclieteAEsperar
        void EnviarClienteEsperar(Clientes *clientes);
        ////
        int NoPersonasEnRestaurante(); // extra-> para saber cuantos entraron aqui
        int NoPersonasEnSaladeEspera(); // extra-> para saber cuantos entraron aqui

        //Salas de Espera con random
        bool EnviarRestaurantes(Clientes *clientes);//envio a restaurantes
        bool EnviarSalaEspera(Clientes *clientes);//encio a sala de espera
        //reducionessaladeespera
        void ReducirSaLasdeEspera();


    protected:
    private:
};

#endif // LISTASESTACIONES_H

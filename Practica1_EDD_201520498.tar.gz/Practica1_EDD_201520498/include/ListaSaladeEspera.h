#ifndef LISTASALADEESPERA_H
#define LISTASALADEESPERA_H
#include <ListaSaladeEspera.h>
#include <SaladeEspera.h>


class ListaSaladeEspera
{
    public:
        ListaSaladeEspera();
        virtual ~ListaSaladeEspera();

        int id_actual =0 ;
        SaladeEspera *primero=NULL;
        SaladeEspera *ultimo=NULL;

        void Agregar_Espera(SaladeEspera *Espera);
        bool EstadodeSala = false;
        int NoPersonaenSala();


    protected:
    private:
};

#endif // LISTASALADEESPERA_H

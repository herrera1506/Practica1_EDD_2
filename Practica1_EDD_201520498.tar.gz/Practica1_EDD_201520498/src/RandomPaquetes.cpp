#include "RandomPaquetes.h"
#include <Paqueteria.h>

RandomPaquetes::RandomPaquetes()
{
    //ctor
}

RandomPaquetes::~RandomPaquetes()
{
    //dtor
}

Paqueteria* RandomPaquetes::AgregarPaquetesRandom(int dato){

    int id=dato;
    int Tipo = 2 + rand() % (4-0);
    int Asutos = 0 +rand()% (2-1);//2 por llegada y 1 por entrar
    int Ingresando=0;

        string Nombre_Paquete ="Paquete:";
        string TipoPaquete_PaqueteT="";
        string Asunto_Paquete="";

        if(Tipo == 4){
            TipoPaquete_PaqueteT="Paquete Premium";
        }
        else if (Tipo ==3){
            TipoPaquete_PaqueteT="Paquete Basico";

        }
        else if (Tipo ==2){
            TipoPaquete_PaqueteT="Paquete MedioMedio";

        }
        else {
            TipoPaquete_PaqueteT="Paquete SuperCompleto";

        }
        //
        if(Asutos ==2){

            Asunto_Paquete="Entrando Paquete al Hangar";
            Ingresando=1;
        }
        else{

             Asunto_Paquete="Saliendo del Hangar";
        }

         Paqueteria *Random_Paquetess = new Paqueteria(id,Nombre_Paquete,TipoPaquete_PaqueteT,Asunto_Paquete,Ingresando);

        return Random_Paquetess;
}





#include "ListaVuelos.h"
#include <Vuelos.h>

ListaVuelos::ListaVuelos()
{
    //ctor
}

ListaVuelos::~ListaVuelos()
{
    //dtor
}

void ListaVuelos::Agregar_Vuelos(Vuelos * Vueloss){

    Vuelos* Nodo_Vuelos =Vueloss;
    Nodo_Vuelos->id=id_actual;

     if (primero != NULL)
    {
        Vuelos* aux = Nodo_Vuelos;
        aux->Siguiente = primero;
        aux->Siguiente->Anterior = aux;
        primero = aux;
    }
    else {
        primero = Nodo_Vuelos;
        ultimo = Nodo_Vuelos;
    }

}

void ListaVuelos::mostrar_datos(Vuelos *Vue){
    Vuelos *aux = Vue;
        cout<<"************************Vuleos******************\n";
        cout<<" Vuelo :"<<aux->id<<"  Nombre: "<<aux->nombre<<"\n";
        cout<<" No. de Pasajeros :"<< aux->Cantidad_Pasajeros<<" \n";
        cout<<" Cantidad de Equipaje "<<aux->Cantidad_Equipajes<<" \n";
        cout<<" Cantidad de Paquetes :"<<aux->Cantidad_Paquetes<<" \n";
        cout<<" Situacion: "<<aux->Informacion<<"\n";
}

int ListaVuelos::Contar()
{
    Vuelos *aux = primero;
   int n =0 ;
   while(aux!=nullptr)
   {
       n++;
       aux= aux->Siguiente;
   }
   return n;
}

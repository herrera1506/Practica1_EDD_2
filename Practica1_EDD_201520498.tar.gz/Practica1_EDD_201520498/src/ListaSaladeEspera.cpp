#include "ListaSaladeEspera.h"
#include <SaladeEspera.h>

ListaSaladeEspera::ListaSaladeEspera()
{
    //ctor
}

ListaSaladeEspera::~ListaSaladeEspera()
{
    //dtor
}

void ListaSaladeEspera::Agregar_Espera(SaladeEspera *Espera){

    SaladeEspera *Nodo_SaladeEspera = Espera;
    Nodo_SaladeEspera->Id =id_actual;

    if(primero!=NULL)
    {

         ultimo->siguiente = Nodo_SaladeEspera;
        Nodo_SaladeEspera->anterior =ultimo;
        primero->anterior = Nodo_SaladeEspera;
        Nodo_SaladeEspera->siguiente = primero;
        ultimo = Nodo_SaladeEspera;


    }
    else
    {

        primero = Nodo_SaladeEspera;
        ultimo = Nodo_SaladeEspera;

}
}

int ListaSaladeEspera::NoPersonaenSala(){
    SaladeEspera *aux = primero;
    int personas =0;
    do
    {
      personas++;
      aux = aux->siguiente;

    }
    while(aux != NULL && aux != ultimo->siguiente);
        return personas;


}

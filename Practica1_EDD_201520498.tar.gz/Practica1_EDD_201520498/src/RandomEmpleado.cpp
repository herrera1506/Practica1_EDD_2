#include "RandomEmpleado.h"
#include <stdlib.h>
#include <time.h>
#include <Clientes.h>
#include <iostream>
#include <string>
#include <ListaEmpleado.h>
#include <Empleados.h>

using namespace std;
RandomEmpleado::RandomEmpleado()
{
    //ctor
}

RandomEmpleado::~RandomEmpleado()
{
    //dtor
}

Empleados* RandomEmpleado::AgregarEmpleadoRandom(int dato){

    int Random = 6 + rand() % (20 -10);
    int Interaciones = Random +rand() % (25-1);
    cout<<"Numero De Interaciones"<<Interaciones;
    ListaEmpleado *RandomClie = new ListaEmpleado();

    int x=0;
        int TipoEmpleado = 1 + rand() % (1-0);//0= tripulacion y 1 Administrativo
        int InformacionEmpleado = 0 + rand() % (5-1);//Nombre,
        int UbicacionEmpleado = 0 +rand()%(2-0);//0=Paquetes , 1 = AtencionalCliente, 2=Seguridad;
        int horario;

        //string TipoEmpleado, string Informacion, string Empleado_Ubicacion
    string Tipo_Empleado="";
    string Informacion_Empleado="";
    string Ubicacion_Empleado=";";
    string Nombre_Empleado="";
    int Id= dato;

    ////Informacion
    if (InformacionEmpleado == 5 ){
            Informacion_Empleado="Edgar";

    }
    else if (InformacionEmpleado == 4){
            Informacion_Empleado="Manuel";

    }else if( InformacionEmpleado == 3){
            Informacion_Empleado="Maria";

    }else if(InformacionEmpleado == 2){
            Informacion_Empleado="Fernanda";
    }
    else {
            Informacion_Empleado="Oscar";
    }

    Nombre_Empleado="Empleado" + to_string(Id);
    //
    if(UbicacionEmpleado==1){

        Ubicacion_Empleado="Area de Atencion";

    }
    else if(UbicacionEmpleado==2){
        Ubicacion_Empleado="Area de Seguridad";

    }
    else{
        Ubicacion_Empleado="Area de Espera";

    }

    if (Interaciones =! 25)
    {

    }


        /*int Id, string Informacion, string TipodeEquipaje, string AsuntodeEquipaje, int Estaciones
         Equipaje *Random_Equipajess = new Equipaje(id,Nombre_Equipaje,TipoPaquete_Equipaje,Asunto_Equipaje);

        return Random_Equipajess;
int Id, int Turno, string Nombre, string Informacion, string Empleado_Ubicacion*/
        Empleados *RamdonEquipajess = new Empleados(Id,Interaciones,Nombre_Empleado,Informacion_Empleado,Ubicacion_Empleado);

        return RamdonEquipajess;

}

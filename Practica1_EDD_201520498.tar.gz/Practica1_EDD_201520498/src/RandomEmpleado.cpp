#include "RandomEmpleado.h"
#include <stdlib.h>
#include <time.h>
#include <Clientes.h>
#include <iostream>
#include <string>
#include <ListaEmpleado.h>
#include <Empleados.h>

using namespace std;
RandomEmpleado::RandomEmpleado()
{
    //ctor
}

RandomEmpleado::~RandomEmpleado()
{
    //dtor
}

Empleados* RandomEmpleado::AgregarEmpleadoRandom(int dato){

    int Turnoss = 3 + rand() % (25-3);
    int Informacion = 1 + rand() % (2-0);
    int UbicacionEmpleado =  1 + rand() % (2-0);
        //string TipoEmpleado, string Informacion, string Empleado_Ubicacion
    string Informacion_Empleado="";
    string Ubicacion_Empleado=";";
    string Nombre_Empleado="Empleado :";
    int Id= dato;
    int turnoss=turnos;

    ////Informacion
    if (InformacionEmpleado == 5 ){
            Informacion_Empleado="Hombre";

    }
    else {
            Informacion_Empleado="Mujer";
    }

    Nombre_Empleado="Empleado" + to_string(Id);
    //
    if(UbicacionEmpleado==1){

        Ubicacion_Empleado="Area de Atencion";

    }
    else if(UbicacionEmpleado==2){
        Ubicacion_Empleado="Area de Seguridad";

    }                                               //int Id, int Turno, string Nombre, string Informacion, string Empleado_Ubicacion,int Tipo
        Empleados *RamdonEquipajess = new Empleados(Id,Turno,Nombre_Empleado,Informacion_Empleado,Ubicacion_Empleado,UbicacionEmpleado);

        return RamdonEquipajess;

}

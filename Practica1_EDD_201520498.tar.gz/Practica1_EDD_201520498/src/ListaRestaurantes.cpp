#include "ListaRestaurantes.h"

ListaRestaurantes::ListaRestaurantes()
{
    //ctor
}

ListaRestaurantes::~ListaRestaurantes()
{
    //dtor
}

void ListaRestaurantes::Agregar_Restaurantes(Restaurantes *Resta){

     Restaurantes *Nodo_restaurante = Resta;
     Nodo_restaurante->id = id_actual;

    if(primero!=NULL)
    {

        ultimo->siguiente = Nodo_restaurante;
        Nodo_restaurante->anterior = ultimo;
        ultimo = Nodo_restaurante;

    }
    else
    {
         primero = Nodo_restaurante;
         ultimo = Nodo_restaurante;

}
}

int ListaRestaurantes::CantidadenRestaurante(){
    Restaurantes *aux = primero;
    int No_Personas = 0;
    while(aux!=NULL)
    {
        No_Personas = No_Personas + aux->capacidad;
        aux = aux->siguiente;
    }
return No_Personas;

}

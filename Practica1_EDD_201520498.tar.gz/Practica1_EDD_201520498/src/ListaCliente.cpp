#include "ListaCliente.h"
#include <Clientes.h>
#include <ListaCliente.h>
#include <iostream>


ListaCliente::ListaCliente()
{
    //ctor
    primero=NULL;
    ultimo=NULL;
}

ListaCliente::~ListaCliente()
{
    //dtor
}

void ListaCliente::AgregarDatos2(Clientes *Nuevo_Nodo_Cliente){

    Clientes *Nuevo_Cliente = Nuevo_Nodo_Cliente;
    Nuevo_Cliente->id =Id_Actual;

    if( primero != NULL){
        ultimo->Siguiente = Nuevo_Cliente;
        Nuevo_Cliente->Anterior = ultimo;
        ultimo = Nuevo_Cliente;
    }else {

       primero = Nuevo_Cliente;
       ultimo = Nuevo_Cliente;
    }
    }


void ListaCliente::MostrarDatos()
{
      Clientes *aux =primero;
    while(aux != NULL)
    {
        cout<<"ID: "<< aux->Nombre<<"   Edad:   "<<aux->Edad<<"  Informacion:  "<<aux->Informacion<<"\n";;
        aux= aux->Siguiente;


    }
}

void ListaCliente::MostrarDatos2(Clientes *Llamado){

 Clientes *aux =Llamado;
         cout<<"\n   | "<<aux->id<<" -  Nombre: "<<aux->Nombre<<"  \n   | "<<aux->id<<" -  Edad: "<< aux->Edad<<"  \n   | "<<aux->id<<" -  Tipo de Cliente: "<<aux->TipoCliente<<"\n";

}



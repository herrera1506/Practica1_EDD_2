#include "ListaEquipaje.h"
#include <Equipaje.h>

ListaEquipaje::ListaEquipaje()
{
    //ctor
}

ListaEquipaje::~ListaEquipaje()
{
    //dtor
}

void ListaEquipaje::AgregarEquipaje(Equipaje *Equipajess){

    Equipaje * Nodo_Equipaje =Equipajess;
    Nodo_Equipaje->Id=Id_Actual;

     if (primero != NULL)
    {
     ultimo->Siguiente = Nodo_Equipaje;
     Nodo_Equipaje->Anterior = ultimo;
     ultimo = Nodo_Equipaje;
    }
    else {
        primero = Nodo_Equipaje;
        ultimo = Nodo_Equipaje;
    }
}


void ListaEquipaje::MostrarDatos(Equipaje *Equi){
    Equipaje *aux =Equi;
        cout<<"ID: "<< aux->Id<<"  Tipo:   "<<aux->TipodeEquipaje<<"   Asunto:  "<<aux->AsuntodeEquipaje<<"\n";
    }

}


int ListaEquipaje::Contar()
{
   Equipaje *aux = primero;
   int n =0 ;
   while(aux!=NULL)
   {
       n++;
       aux= aux->siguiente;
   }
   return n;

}

#include "ListaFilaColumna.h"
#include <ListaSaladeEspera.h>
#include <EsperaColumna.h>

ListaFilaColumna::ListaFilaColumna()
{
    //ctor
}

ListaFilaColumna::~ListaFilaColumna()
{
    //dtor
}

void ListaFilaColumna::AgregarAsientos(EsperaColumna *Col){

    EsperaColumna *Nodo_Espera_FC = Col;
    Nodo_Espera_FC->id =id_actual;

    if(primero != NULL)
    {
        ultimo->siguiente =Nodo_Espera_FC;
        ultimo = Nodo_Espera_FC;
    }
    else
    {

        primero = Nodo_Espera_FC;
        ultimo = Nodo_Espera_FC;
    }
}

int ListaFilaColumna::No_DePersonasOcupandoLugares()
{
     EsperaColumna *aux = primero;

    int personas =0;
    while(aux!=NULL)
    {
        personas = personas + aux->fila->NoPersonaenSala();

        aux= aux->siguiente;
}
}

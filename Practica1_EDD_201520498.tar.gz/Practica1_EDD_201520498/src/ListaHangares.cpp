#include "ListaHangares.h"
#include <Hangares.h>

ListaHangares::ListaHangares()
{
    //ctor
}

ListaHangares::~ListaHangares()
{
    //dtor
}

void ListaHangares::AgregarHangarares(Hangares *Hangaress){

    Hangares *Nodo_Hangares = Hangaress;
    Nodo_Hangares->Id=id_actual;
    if(primero!=NULL)
    {
       Hangares *temp = Nodo_Hangares;
       temp->siguiente = primero;
       primero = temp;

    }
    else
    {


         primero = Nodo_Hangares;
         ultimo = Nodo_Hangares;

}
}

bool ListaHangares::AgregarVuelo(Vuelos *vueloo){

   Hangares *aux = primero;
    bool subVuelo = false;
    while(aux != NULL)
    {
        if(aux->HangarCasiLleno == false)
        {

            aux->HangarCasiLleno = true;
            aux->Vueloss = vueloo;
            subVuelo = true;
            break;

        }
        aux = aux->siguiente;
    }
return subVuelo;

}

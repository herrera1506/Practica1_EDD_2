#include "ListasEstaciones.h"
#include <iostream>
#include <Clientes.h>
#include <Empleados.h>
#include <string>
#include <ListaCliente.h>
#include <PilaEmpleado.h>
#include <RandomClientes.h>
#include <Paqueteria.h>
#include <RandomPaquetes.h>
#include <ListaPaqueteria.h>
#include <Equipaje.h>
#include <ListaEquipaje.h>
#include <RandomEquipaje.h>
#include <Vuelos.h>
#include <ListaVuelos.h>
#include <RamdonVuelos.h>
#include <ListaEmpleado.h>
#include <RandomEmpleado.h>
#include <Empleados.h>
#include <stdlib.h>
#include <time.h>
#include <ListaEmpleado.h>
#include <Hangares.h>
#include <Estaciones.h>
#include <ListasEstaciones.h>
#include <ListaHangares.h>
#include <Restaurantes.h>
#include <ListaRestaurantes.h>
#include <EsperaColumna.h>
#include <ListaFilaColumna.h>
#include <Estaciones.h>


ListasEstaciones::ListasEstaciones()
{
    //ctor

    *Colo_Espera = new ColaEsperaAtencionalCliente();
    *ColaEquipaje= new ColaEsperaEquipaje();
    * ColaPaquetes =new ColaPaquetes();
}

ListasEstaciones::~ListasEstaciones()
{
    //dtor
}

void ListasEstaciones::AgregarEstaciones(Estaciones *Esta){

    Estaciones *Nodo_Estaciones = Esta;
    Nodo_Estaciones->id=id_actual;

    if(primero != NULL)
    {
        ultimo->siguiente = Nodo_Estaciones;
        Nodo_Estaciones->anterior = ultimo;
        primero->anterior = Nodo_Estaciones;
        Nodo_Estaciones->siguiente = primero;
        ultimo = Nodo_Estaciones;

    }
    else
    {
        primero = Nodo_Estaciones;
        ultimo = Nodo_Estaciones;

}
}


void ListasEstaciones::mostrar_datos(){
    Estaciones *aux = primero;
    do
    {
        if(aux->anterior != NULL)
        {
            cout<<"ANTERIOR ["<<aux->anterior->Nombre<<"]";
        }
        cout<<" - NODO ["<<aux->Nombre<<"]";
        if(aux->siguiente != NULL)
        {
            cout<<" - SIGUIENTE ["<<aux->siguiente->Nombre<<"]";
        }
        aux = aux->siguiente;

}while(aux != NULL && aux!= ultimo->siguiente);
}


bool ListasEstaciones::AgregandoEmpleados(Empleados *empleado_)
{
    Estaciones *aux = primero;
    bool tts = false;
    do
    {
        if(aux->CargoEmpleado == false) /// o !=
        {
            aux->CargoEmpleado = empleado_;
            aux->TieneEmpleados1 = true;
            tts = true;
            cout<<"El Empleado"<<empleado_->Nombre<<"Ingreso a"<<aux->Nombre<<"\n";
            break;
        }
        aux = aux->siguiente;
    }while(aux != NULL && aux!= ultimo->siguiente);
    return tts;
}


bool ListasEstaciones::AsignacionestacionAtencion(Clientes *cliente)
{
    Estaciones *aux = primero;
    bool tts = false;
    while(aux!=NULL && aux->AtencionAlCliente==true)
    {
        if(aux->TieneEmpleados==true && aux->ClientesEnAtenion==NULL)
        {
            aux->ClientesEnAtenion = cliente;
            tts = true;<
            cout<<"El Cliente: "<<cliente->Nombre<<" Se dirige a la Estacion: "<<aux->Nombre<<"\n";
            break;
        }
        aux = aux->siguiente;
    }
    return tts;
}



bool ListasEstaciones::AsignacionesestacionSeguridad(Clientes *cliente)
{
    bool AsignacionSeguridaddd = false;

  if(cliente->Informacion == "Mujer Embarazada" || cliente->Informacion=="Persona Discapacitada" || cliente->Informacion=="Persona Mayor de Edad"){
        ColaEsperaAtencionCliente->AgregarAlInicio(cliente);
        ColaEsperaAtencionCliente->id_actual++;
        return true;
  }

  else
    {
        ColaEsperaAtencionCliente->AgregarNormal(cliente);
        ColaEsperaAtencionCliente->id_actual++;
        return true;
    }
 return AsignacionSeguridaddd;
}


bool ListasEstaciones::AsignacionestacionSeguridad1(Equipaje *equipaje)
{
    ColaEquipaje->AgregarEquipajeSala(equipaje);
    ColaEquipaje->id_actual++;
    return tts;
}


bool ListasEstaciones::AsignacionestacionSeguridad2(Paqueteria *paquete)
{
    ColaPaquetes->AgregarColaPaquetes(paquete);
    ColaPaquetes->id_actual++;
    return tts;
}

void ListasEstaciones::EliminarSeguridad(){

     Estaciones *aux1EliminarS =primero;

    do
    {
        if(aux1EliminarS->SeguridadCliente == true && aux1EliminarS->TieneEmpleados1 == true && aux1EliminarS->ClientesEnEstaciones!=NULL)
        {
            if(aux1EliminarS->ClientesEnEstaciones->primero!=NULL)
            {
                EliminarSeguridadConPuntero(aux1EliminarS);
            }
            else
            {
                cout<<"\n La Estacion de Seguridad No."<<aux1EliminarS->id<<", Se encuentra vacia \n";
            }


        }
      aux1EliminarS=aux1EliminarS->siguiente;
    }while(aux1EliminarS!=NULL && aux1EliminarS != ultimo->siguiente)
}

void ListasEstaciones::EliminarSeguridad2(Estaciones * estacion)
{
   int random  = 1 + rand() % (3-1);
    Estaciones *auxSeguridadEquipaje = this->primero;
    int n = 0;
    do
    {
        n++;
        if(n==random)
        {

            ActualizarEquipaje(auxSeguridadEquipaje)
        }

        auxSeguridadEquipaje = auxSeguridadEquipaje->siguiente;
    }while(auxSeguridadEquipaje!=nullptr && auxSeguridadEquipaje!= this->ultimo->siguiente);
}


void ListasEstaciones::EliminarSeguridad3(Estaciones *estacion)
{
    int random  = 1 + rand() % (3-1);
    Estaciones *auxSeguridadPaquetes = primero;
    int n = 0;
    do
    {
        n++;
        if(n==random)
        {

            ActualizarPaquetes(auxSeguridadPaquetes);
        }

        auxSeguridadPaquetes = auxSeguridadPaquetes->siguiente;
    }while(auxSeguridadPaquetes!=NULL && auxSeguridadPaquetes!= ultimo->siguiente);
}


void ListasEstaciones::ActualizarPaquetes(Estaciones *estacion)
{
    ColaPaquetes->PUSH(estacion->Nombre);
}
void ListasEstaciones::ActualizarEquipaje(Estaciones *estacion)
{

     ColaEsperaEquipaje->Push(estacion->nombre);

}



void ListasEstaciones::EliminarSeguridadConPuntero(Estaciones *estacion){

    cout<<" Estacion -> "<<estacion->Nombre;
    Clientes *Envio = estacion->ClientesEnEstaciones;
    estacion->ClientesEnEstaciones = NULL;

    if(estacion->TieneEmpleados1 == true)
    {

        Clientes *Clientejalado = TraerColasSeguridad(estacion);

        if(Clientejalado!=NULL)
        {
          estacion->ClientesEnEstaciones = Clientejalado;

          cout<<"\n El Cliente: "<<Clientejalado->nombre<<"] ingreso a una estacion de seguridad \n";
          cout<<"Estacion: "<<estacion->id<<"\n";

        }
        else
        {

        cout<<"Estacion_"<<estacion->id<<" tiene clientes pendientes \n";

        }

    }
    else
    {
         cout<<"En la estacion de seguridad No."<<estacion->id<<" no hay un empleado atendiendo \n";
    }

    int random = 0 + rand() % (2-1);//// np crorre hasta este punto

    if(random==1)
    {
        //EnviarASalaEspera(SalaEspera, Envio);
        EnviarASalaEspera(SaladeEspera, Envio);

    }
    else
    {
        EnviarARestaurantes(restaurante, Envio);
        EnviarARestaurantes(restaurante,Envio);

    }

}

Clientes* ListasEstaciones::traer_decolaseguridad(Estaciones *estacion)
{
    Clientes *envio = ColaEsperaAtencionCliente->EnviarSiguiente();
    ColaEsperaAtencionCliente->push_();
    return envio;
}

void ListasEstaciones::EnviarARestaurantes(ListaRestaurantes *Restaurantes, Clientes *clientes){

    ListaRestaurantes *auxListaRestaurantes = restaurante;

    Restaurantes *aux = auxListaRestaurantes->primero;

    while(aux!=NULL)
    {
        if(aux->capacidad!=0)
        {
          int kkl = 1 + rand() % (15-5);
          clientes->Tiempo_Vuelo= kkl;
          aux->cliente->AgregarAlInicio(clientes);
          cout<<" El Cliente: "<<clientes->Nombre<<" ingreso al restaurante_"<<aux->id<<"] \n";
          aux->capacidad--;
          break;
        }
        else
        {
            cout<<" Ya no hay espacio en el resturante_"<<aux->id<<endl;
        }
        aux = aux->siguiente;
    }
}



void ListasEstaciones::EnviarASaladeEspera(ListaFilaColumna *sala, Clientes *clientes)
{
    ListaFilaColumna *auxSalaFilaColumna = sala;
    bool entra = true;

    EsperaColumna *auxColumna = auxSalaFilaColumna->primero;

    while(auxColumna!=NULL)
    {
        SaladeEspera *auxSaladeEspera = auxColumna->fila->primero;
        do
        {
            if(auxColumna-> EnUso== false && entra == true)
            {
                int kkl = 1 + rand() % (15-5);
                clientes->Tiempo_Vuelo = kkl;
                auxSaladeEspera->Cola_Clientes = clientes;
                cout<<" El Cliente: "<<clientes->Nombre<<"] ingreso a la sala de espera \n";
                cout<<" Lugar  Fila: "<<auxColumna->id<<"] - [ Columna :"<<auxSaladeEspera->id<<"n";;
                auxColumna->EnUso=true;
                entra = false;
                break;
            }

            auxSaladeEspera = auxSaladeEspera->siguiente;

        }while(auxSaladeEspera!=NULL && auxSaladeEspera!= auxColumna->fila->ultimo->siguiente);
        auxColumna = auxColumna->siguiente;
    }

}


void ListasEstaciones::EliminarAtencion()
{
    Estaciones *aux = primero;
    if(aux!=NULL)
    {
        do
        {
            if(aux->AtencionAlCliente1==true && aux->TieneEmpleados1 == true && aux->ClientesEnEstaciones!=nullptr)
            {

                //eliminar_atention(aux);
                EliminarAtenciones(aux);

            }

            aux = aux->siguiente;

        }while(aux!=NULL && aux!=ultimo->siguiente);
    }

}

void ListasEstaciones::EliminarAtenciones(Estaciones *estacion)
{
    Estaciones * esta = estacion;
    cout<<" Estacion: "<<esta->Nombre<<"\n";
    Clientes *clienteaMover = esta->ClientesEnEstaciones;
    esta->ClientesEnEstacionesiente_enatencion = NULL;
    if(ColaEsperaAtencionCliente->actual>0)
    {
        Clientes *Clientejalado = TraerdeColaDeEspera();
        esta->ClientesEnEstaciones= Clientejalado;
        cout<<"\n El Cliente: "<<Clientejalado->Nombre<<"] Esta en atencion al Cliente \n";
        cout<<"Estacion_"<<estacion->id<<"\n";
     bool ingre = AsignacionesestacionSeguridad(clienteaMover);
     if(ingre == true)
     {
         cout<<"Cliente "<<Clientejalado->Nombre<<", esta en Estacion de Seguridad  \n";
         cout<<" Estacion_"<<esta->id<<"\n";

     }
     else
     {
         cout<<"Cliente: "<<Clientejalado->Nombre<<"Ya no viajo el cliente"<<endl;

     }
    }
    else
    {
        cout<<"\n Centro de Atencion Vacio"<<endl;
        bool ingre = AsignacionesestacionSeguridad(clienteaMover);
         if(ingre == true)
         {
             cout<<"\n El Cliente: "<<clienteaMover->Nombre<<"] ingreso a la estacion de seguridad \n";
             cout<<" Con nombre Estacion_"<<esta->id<<"\n";

         }
         else
         {
             cout<<"El Cliente: "<<clienteaMover->Nombre<<" Ya no viajo \n";

         }

    }

}


Clientes* ListasEstaciones::TraerdeColaDeEspera()
{
    Clientes *Asignacionllamar = ColaEsperaAtencionCliente->primero;
    Clientes *EnvioAsignacion = ColaEsperaAtencionCliente->primero;

if(Asignacionllamar!=NULL)
{
    if(Asignacionllamar->Siguiente!=NULL)
    {
        Clientes *NodoPrimero = Asignacionllamar->Siguiente;
        NodoPrimero->Anterior = NULL;
        ColaEsperaAtencionCliente->primero = NodoPrimero;
        ColaEsperaAtencionCliente->actual--;
        delete Asignacionllamar;
    }
    else
    {
        delete Asignacionllamar;
    }
}
    return EnvioAsignacion;
}

void ListasEstaciones::EliminarSeguridadConPuntero(Clientes *cliente)
{
   Estaciones *pivote = primero;
   Estaciones *estacion;

    do
    {
        if(pivote->SeguridadCliente1 == true && pivote->TieneEmpleados1 == true && pivote->ClientesEnEstaciones==NULL)
        {
           estacion = pivote;

        }
        pivote = pivote->siguiente;

    }while(pivote != NULL && pivote!=ultimo->siguiente);

    estacion->ClientesEnEstaciones=Colo_Espera ->primero;

    Clientes *NodoEliminar =Colo_Espera->primero;
    Clientes *Envio = NodoEliminar;

    if(NodoEliminar->Siguiente!=NULL)
    {
        Clientes *aux = NodoEliminar;
        NodoEliminar = NodoEliminar->Siguiente;
        NodoEliminar->Anterior = NULL;
        Colo_Espera->primero = NodoEliminar;

        delete aux;

    }
    else
    {

        delete Colo_Espera->primero;
        Colo_Espera->primero = NULL;

    }
    Colo_Espera->AgregarAlInicio(cliente);
    cout<<"\n El Cliente: "<<cliente->Nombre<<" ingreso a la estacion de seguridad \n";

}


void ListasEstaciones::ActualizarEmpleados()
{
        Estaciones *auxActualizar = this->primero;

    do
    {
        if(auxActualizar->TieneEmpleados1==true)
        {
            auxActualizar->CargoEmpleado->Turno--;
            if(auxActualizar->CargoEmpleado->Turno<1)
            {
                cout<<" El empleado "<<auxActualizar->CargoEmpleado->Nombre<<" termino su turno \n";
                auxActualizar->empleado_acargo = nullptr;
                auxActualizar->tiene_empleado = false;
            }
        }
    }while(auxActualizar!=NULL && auxActualizar!=ultimo->siguiente);
}


#include "ListasEstaciones.h"
#include <iostream>
#include <Clientes.h>
#include <Empleados.h>
#include <string>
#include <ListaCliente.h>
#include <PilaEmpleado.h>
#include <RandomClientes.h>
#include <Paqueteria.h>
#include <RandomPaquetes.h>
#include <ListaPaqueteria.h>
#include <Equipaje.h>
#include <ListaEquipaje.h>
#include <RandomEquipaje.h>
#include <Vuelos.h>
#include <ListaVuelos.h>
#include <RamdonVuelos.h>
#include <ListaEmpleado.h>
#include <RandomEmpleado.h>
#include <Empleados.h>
#include <stdlib.h>
#include <time.h>
#include <ListaEmpleado.h>
#include <Hangares.h>
#include <Estaciones.h>
#include <ListasEstaciones.h>
#include <ListaHangares.h>
#include <Restaurantes.h>
#include <ListaRestaurantes.h>
#include <EsperaColumna.h>
#include <ListaFilaColumna.h>
#include <Estaciones.h>



ListasEstaciones::ListasEstaciones()
{
    //ctor

   ColaEsperaAtencionalCliente *Colo_Espera = new ColaEsperaAtencionalCliente();
   ColaEsperaEquipaje  *ColaEquipaje= new ColaEsperaEquipaje();
   ColaPaquetes *ColaPaquetess =new ColaPaquetes();
   ListaRestaurantes *CrearResta = new ListaRestaurantes();
   ListaFilaColumna *SalaEspera = new ListaFilaColumna();
   ColaEsperaAtencionalCliente *ColaEsperaAtencionC =new ColaEsperaAtencionalCliente();

}

ListasEstaciones::~ListasEstaciones()
{
    //dtor
}

void ListasEstaciones::AgregarEstacion(Estaciones *estacion)
{
    Estaciones *Nodo_Estaciones = estacion;
    Nodo_Estaciones->id=id_actual;

    if(primero != NULL)
    {
        ultimo->siguiente = Nodo_Estaciones;
        Nodo_Estaciones->anterior = ultimo;
        primero->anterior = Nodo_Estaciones;
        Nodo_Estaciones->siguiente = primero;
        ultimo = Nodo_Estaciones;

    }
    else
    {
        primero = Nodo_Estaciones;
        ultimo = Nodo_Estaciones;
}
}


void ListasEstaciones::mostrar_datos(){
    Estaciones *aux = primero;
    do
    {
        if(aux->anterior != NULL)
        {
            cout<<"ANTERIOR ["<<aux->anterior->Nombre<<"]";
        }
        cout<<" - NODO ["<<aux->Nombre<<"]";
        if(aux->siguiente != NULL)
        {
            cout<<" - SIGUIENTE ["<<aux->siguiente->Nombre<<"]";
        }
        aux = aux->siguiente;

}while(aux != NULL && aux!= ultimo->siguiente);
}


bool ListasEstaciones::AgregandoEmpleados(Empleados *emple)
{
    Estaciones *aux = primero;
    bool abc = false;
    do
    {
        if(aux->CargoEmpleado == false) /// o !=
        {
            aux->CargoEmpleado = emple;
            aux->TieneEmpleados1 = true;
            abc = true;
            cout<<"El Empleado"<<emple->Nombre<<"Ingreso a"<<aux->Nombre<<"\n";
            break;
        }
        aux = aux->siguiente;
    }while(aux != NULL && aux!= ultimo->siguiente);
    return abc;
}


bool ListasEstaciones::AsignacionestacionAtencion(Clientes *cliente)
{
    Estaciones *aux = primero;
    bool tts = false;
    while(aux!=NULL && aux->AtencionAlCliente1==true)
    {
        if(aux->TieneEmpleados1==true && aux->ClientesEnEstaciones==NULL)
        {
            cliente->Informacion= cliente->Informacion+"Ingreso para Atencion al Cliente \n";
            aux->ClientesEnEstaciones=cliente;
            tts = true;
            cout<<"El Cliente: "<<cliente->Nombre<<" Se dirige a la Estacion: "<<aux->Nombre<<"\n";
            break;
        }
        aux = aux->siguiente;
    }
    return tts;
}



bool ListasEstaciones::AsignacionesestacionSeguridad(Clientes *cliente)
{
    Estaciones *auxAsignacion =primero;
    bool tts = false;
    while(auxAsignacion!=NULL && auxAsignacion->SeguridadCliente1==true)
    {
        if(auxAsignacion->TieneEmpleados1==true && auxAsignacion->ClientesEnEstaciones==NULL)
        {
            cliente->Informacion = cliente->Nombre+"\n ingreso a estacion de seguridad";
            auxAsignacion->ClientesEnEstaciones = cliente;
            tts = true;
            break;
        }
        auxAsignacion = auxAsignacion->siguiente;
    }
 return tts;
}


bool ListasEstaciones::AsignacionestacionSeguridad1(Equipaje *equipaje)
{
    ColaEquipaje->AgregarEquipajeSala(equipaje);
    ColaEquipaje->id_actual++;
    return true;
}


bool ListasEstaciones::AsignacionestacionSeguridad2(Paqueteria *paquete)
{
    //ColaPaquetes->AgregarColaPaquetes(paquete);
    this->ColaPaquetess->AgregarColaPaquetes(paquete);
    this->ColaPaquetess->id_actual++;
    return true;
}

void ListasEstaciones::EliminarSeguridad2()
{
   cout<<"Centro de Seguridad para Equipaje \n";
   int random  = 1 + rand() % (3-1);
    Estaciones *auxSeguridadEquipaje = this->primero;
    int n = 0;
    do
    {
        n++;
        if(n==random)
        {

            ActualizarEquipaje(auxSeguridadEquipaje);
        }

        auxSeguridadEquipaje = auxSeguridadEquipaje->siguiente;
    }while(auxSeguridadEquipaje!=nullptr && auxSeguridadEquipaje!= this->ultimo->siguiente);
}


void ListasEstaciones::EliminarSeguridad3()
{
    cout<<"Centro de Seguridad para Paquetes \n";
    int random  = 1 + rand() % (3-1);
    Estaciones *auxSeguridadPaquetes = primero;
    int n = 0;
    do
    {
        n++;
        if(n==random)
        {

            ActualizarPaquetes(auxSeguridadPaquetes);
        }

        auxSeguridadPaquetes = auxSeguridadPaquetes->siguiente;
    }while(auxSeguridadPaquetes!=NULL && auxSeguridadPaquetes!= ultimo->siguiente);
}


void ListasEstaciones::ActualizarPaquetes(Estaciones *estacion)
{
    cout<<"Lista de Paquetes \n";
    ColaPaquetess->PUSH(estacion->Nombre);
}
void ListasEstaciones::ActualizarEquipaje(Estaciones *estacion)
{
        cout<<"Lista de Equipajes \n";
        ColaEquipaje->Push(estacion->Nombre);
}

void ListasEstaciones::ActualizarEmpleados()
{
    cout<<"Verificando Empleados en Turno \n";
        Estaciones *auxActualizar = primero;

    do
    {
        if(auxActualizar->TieneEmpleados1==true)
        {
            auxActualizar->CargoEmpleado->Turno--;
            if(auxActualizar->CargoEmpleado->Turno<1)
            {
                cout<<" El empleado "<<auxActualizar->CargoEmpleado->Nombre<<" termino su turno \n";
                auxActualizar->CargoEmpleado = NULL;
                auxActualizar->TieneEmpleados1 = false;
            }
        }
    }while(auxActualizar!=NULL && auxActualizar!=ultimo->siguiente);
    cout<<"Salieron de Labores \n";
}


void ListasEstaciones::ReducirenRestaurantes(){
    Restaurantes *auxResta = CrearResta->primero;
    while(auxResta!=NULL)
    {
        auxResta = auxResta->siguiente;
        ReduceEltiempodeVuelo(auxResta);

    }
}


void ListasEstaciones::ReduceEltiempodeVuelo(Restaurantes *restaurante){

    cout<<"Ingresando a Restaurantes"<<restaurante->id<<"\n";
    //Clientes *auxClientes = restaurante->cliente->primero;
    Clientes *auxClientes =restaurante->cliente->primero;

      while(auxClientes!=NULL)
      {
          auxClientes->Tiempo_Vuelo--;
          if(auxClientes->Tiempo_Vuelo<1)
          {
              PersonasSalieronAlAvion++;
              cout<<" El cliente "+auxClientes->Nombre+" abordo su vuelo \n";
              SalidadelAvion(auxClientes);
              restaurante->capacidad++;
          }
          auxClientes = auxClientes->Siguiente;
      }
      cout<<" saliendo del restaurante";
}


void ListasEstaciones::SalidadelAvion(Clientes *cliente){

  cout<<" Ingresando A Hangares \n ";
  Hangares *hangar = hangares->primero;

    while(hangar!=NULL)
    {
        if(hangar->HangarCasiLleno==true)
        {
            hangar->Vueloss->ClientesVolando->AgregarDatos2(cliente); //// o es agregar 1
            hangar->Vueloss->ClientesVolando->Id_Actual++;
            hangar->Vueloss->Cantidad_Pasajeros--;
            if(hangar->Vueloss->Cantidad_Pasajeros<1)
            {
                cout<<" El vuelo "<<hangar->Vueloss<<" ya partio"<<endl;
                AvionesQueDespegaron++;
                hangares->PUSH(hangar->Vueloss);
                hangar->HangarCasiLleno= false;
                break;
            }
            break;
        }
        hangar = hangar->siguiente;
    }
    cout<<"**************************************************"<<endl;


}


int ListasEstaciones::EncontrarE(){

    int empleados=0;
    Estaciones *pivote = primero;
    do
    {
        if(pivote->TieneEmpleados1==true)
        {
            empleados++;
        }
        pivote = pivote->siguiente;

    }while(pivote!=NULL && pivote != ultimo->siguiente);
    return empleados;
}

void ListasEstaciones::ActualizarEA(){
  Estaciones *pivote = primero;
    do
    {
        if(pivote->AtencionAlCliente1==true)
        {
            if(pivote->TieneEmpleados1==true)
            {
                if(pivote->ClientesEnEstaciones==NULL)
                {
                    Clientes *cliente = ColaEsperaAtencionC->EnviarSiguiente();
                    if(cliente!=NULL)
                    {
                        pivote->ClientesEnEstaciones = cliente;
                        cout<<" El cliente ["<<cliente->Nombre<<"] ingreso a la estacion ["<<pivote->Nombre<<"] \n"<<endl;
                        ColaEsperaAtencionC->push_();
                        break;
                    }
                    else
                    {
                        cout<<" ya no hay clientes en la cola de espera de atencion \n"<<endl;
                        break;
                    }
                }
            }
        }
        pivote = pivote->siguiente;

    }while(pivote!=nullptr && pivote!=ultimo->siguiente);


}


void ListasEstaciones::AdquirirEA(){

   cout<<"  informacion Estacion Atencion  \n";
    Estaciones *pivote = primero;
    do
    {
        if(pivote->AtencionAlCliente1==true)
        {
            if(pivote->TieneEmpleados1==true)
            {
                if(pivote->ClientesEnEstaciones!=nullptr)
                {
                    ActualizarE(pivote->ClientesEnEstaciones, pivote);
                }
            }
        }
        pivote= pivote->siguiente;
    }while(pivote!=NULL && pivote!=ultimo->siguiente);
}

Clientes* ListasEstaciones::NuevoclienteAtencion()
{
       if(ColaEsperaAtencionC->actual>0)
    {
        Clientes *nuevo = ColaEsperaAtencionC->EnviarSiguiente();
        ColaEsperaAtencionC->push_();
        return nuevo;
    }
    else
    {
        return NULL;
    }
}

void ListasEstaciones::ActualizarE(Clientes *clientes, Estaciones *estacion){
    Clientes *nuevo_atencion = NuevoclienteAtencion();
    if(nuevo_atencion!=NULL)
    {
        estacion->ClientesEnEstaciones= nuevo_atencion;
        cout<<" EL cliente "<<nuevo_atencion->Nombre<<" ingreso a la estacion: "<<estacion->Nombre<<"\n";

    }
    else
    {
        estacion->ClientesEnEstaciones = NULL;
        cout<<" La estacion ["<<estacion->Nombre<<"] quedo vacia \n"<<endl;
    }
    //Enviar(clientes)
    EnviarClienteAS(clientes);
}

void ListasEstaciones::EnviarClienteAS(Clientes *cliente){

    Estaciones *estacion_1 = PreguntarEstadoSeguridad();
    if(estacion_1!=NULL)
    {
        estacion_1->ClientesEnEstaciones = cliente;
        cout<<" El cliente ["<<cliente->Nombre<<"] ingreso a la Estacion ["<<estacion_1->Nombre<<"] \n"<<endl;
    }
    else
    {
        Colo_Espera->AgregarNormal(cliente);
        Colo_Espera->id_actual++;
        cout<<" El cliente ["<<cliente->Nombre<<"]  ingreso a la cola para Estacion de Seguridad \n"<<endl;
    }

}

Estaciones *ListasEstaciones::PreguntarEstadoSeguridad(){
    Estaciones *pivote = primero;
    Estaciones *aux = NULL;
    do
    {
        if(pivote->SeguridadCliente1==true)
        {
            if(pivote->TieneEmpleados1==true)
            {
                aux = pivote;
                break;
            }
        }
        pivote = pivote->siguiente;
    }while(pivote!=NULL && pivote!=ultimo->siguiente);

    return aux;
}

void ListasEstaciones::ActualizarES()
{
    Estaciones *pivote = this->primero;
    do
    {
        if(pivote->SeguridadCliente1==true)
        {
            if(pivote->TieneEmpleados1==true)
            {
                if(pivote->ClientesEnEstaciones==NULL)
                {
                    Clientes *cliente = Colo_Espera->EnviarSiguiente();
                    if(cliente!=NULL)
                    {
                        pivote->ClientesEnEstaciones= cliente;
                        cout<<" El cliente ["<<cliente->Nombre<<"] ingreso a la estacion ["<<pivote->Nombre<<"] \n";
                        Colo_Espera->push_();
                        break;
                    }
                    else
                    {
                        cout<<" ya no hay clientes en la cola de espera de seguridad \n";
                        break;
                    }
                }
            }
        }
        pivote = pivote->siguiente;

    }while(pivote!=NULL && pivote!=ultimo->siguiente);
}

void ListasEstaciones::AdquirirEstadoSeguridad(){

    cout<<" Informacion Estacion_Seguridad \n";
    Estaciones *pivote = primero;

    do
    {
        if(pivote->SeguridadCliente1==true)
        {
            if(pivote->TieneEmpleados1==true)
            {
                if(pivote->ClientesEnEstaciones!=NULL)
                {
                    ActualizarE1(pivote->ClientesEnEstaciones,pivote);
                }
            }
        }
        pivote = pivote->siguiente;
    }while(pivote!=NULL && pivote!=ultimo->siguiente);
}

Clientes* ListasEstaciones::NuevoClienteSeguridad(){
  if(Colo_Espera->actual>0)
    {
        Clientes *nuevo = Colo_Espera->EnviarSiguiente();
        Colo_Espera->push_();
        return nuevo;
    }
    else
    {
        return NULL;
    }

}

void ListasEstaciones::ActualizarE1(Clientes *clientes,Estaciones * estacion){

    Clientes *NuevoSeguridad = NuevoClienteSeguridad();
    if(NuevoSeguridad!=NULL)
    {
        estacion->ClientesEnEstaciones= NuevoSeguridad;
        cout<<" EL cliente: "<<NuevoSeguridad->Nombre<<" ingreso a la estacion No. "<<estacion->No_Estacion<<"\n";

    }
    else
    {
        estacion->ClientesEnEstaciones = NULL;
        cout<<" La estacion: "<<estacion->Nombre<<" quedo vacia \n"<<endl;
    }

    EnviarClienteEsperar(clientes);

}

void ListasEstaciones::EnviarClienteEsperar(Clientes *cliente){

  int random = 1+ rand() % (3-0);

    if(random>0 && random<2)
    {
        bool ingresa = EnviarRestaurantes(cliente);
        if(ingresa != true)
        {
            PerdieronSuvuelodeRestaurantes++;
            cout<<" El cliente:"<<cliente->Nombre<<", fue a su casa \n";
        }
        else
        {
            PesonasRestau++;
        }
    }
    else
    {
        bool ingresa = EnviarSalaEspera(cliente);
        if(ingresa != true)
        {
            PerdieronSuvuelodeRestaurantes++;
            cout<<" El cliente: "<<cliente->Nombre<<"], perdio el vuelo \n";
        }
        else
        {
            PerdieronSuvuelodeSaladeEspera++;
        }
    }

}

bool ListasEstaciones::EnviarRestaurantes(Clientes *clientes){

  cout<<"   Restaurante... \n"<<endl;
    ListaRestaurantes *lista_aux = CrearResta;
    bool entro = false;
    Restaurantes *aux = lista_aux->primero;

    while(aux!=NULL)
    {
        if(aux->capacidad != 0)
        {
          int kkl = 1 + rand() % (15-5);
          clientes->Tiempo_Vuelo = kkl;
          clientes->Informacion = clientes->Informacion + " \n ingreso a Restaurantes \n";
          aux->cliente->AgregarAlInicio(clientes);
          aux->id++;
          cout<<" El Cliente "<<clientes->Nombre<<"ingreso al Restaurante_"<<aux->id<<"] \n "<<endl;
          aux->capacidad--;
          entro = true;
          break;
        }

        aux = aux->siguiente;
    }
    return entro;
}

bool ListasEstaciones::EnviarSalaEspera(Clientes *clientes){
    cout<<" Sala de Espera \n";
    ListaFilaColumna *pivote1 =SalaEspera;
    bool entra = true;
    bool si_sesento =false;
    EsperaColumna *pivote = pivote1->primero;
    while(pivote!=nullptr)
    {
        SaladeEspera *pivote2 = pivote->fila->primero;

        do
        {
            if(pivote2->EstadoLleno == false && entra == true)
            {
                int kkl = 1 + rand() % (15-5);
                clientes->Tiempo_Vuelo = kkl;
                clientes->Informacion = clientes->Informacion + " \n ingreso a la Sala de Espera";
                pivote2->Cola_Clientes = clientes;
                cout<<" El Cliente: "<<clientes->Nombre<<"] ingreso a la sala de espera, F:"<<pivote->id<<"C:"<<pivote2->Id<< "\n";
                pivote2->EstadoLleno=true;
                entra = false;
                si_sesento = true;
                break;
            }

            pivote2 = pivote2->siguiente;

        }while(pivote2!=NULL && pivote2!= pivote->fila->ultimo->siguiente);
        pivote = pivote->siguiente;

    }
    return si_sesento;
}

int ListasEstaciones::NoPersonasEnRestaurante(){

  int personas=0;
  Restaurantes *resta = CrearResta->primero;
  while(resta!=NULL)
  {
      personas = personas + resta->id;
      resta = resta->siguiente;
  }
  return personas;
}


int ListasEstaciones::NoPersonasEnSaladeEspera(){
  ListaFilaColumna *pivote1 =SalaEspera;
    int personas =0;
    EsperaColumna *pivote = pivote1->primero;
    while(pivote!=NULL)
    {
        SaladeEspera *pivote2 = pivote->fila->primero;

        do
        {
            if(pivote2->EstadoLleno == true)
            {
                personas++;
            }

            pivote2 = pivote2->siguiente;

        }while(pivote2!=NULL && pivote2!= pivote->fila->ultimo->siguiente);
        pivote = pivote->siguiente;

    }
    return personas;
}

void ListasEstaciones::ReducirSaLasdeEspera(){
  ListaFilaColumna *pivote1 = SalaEspera;
    EsperaColumna *pivote = pivote1->primero;
    while(pivote!=NULL)
    {
        SaladeEspera *pivote2 = pivote->fila->primero;

        do
        {
            if(pivote2->EstadoLleno == true)
            {
                pivote2->Cola_Clientes->Tiempo_Vuelo--;
                if(pivote2->Cola_Clientes->Tiempo_Vuelo<1)
                {
                    PersonasSalieronAlAvion++;
                    cout<<" El cliente: "<<pivote2->Cola_Clientes->Nombre<<"] abordo su vuelo \n";
                    SalidadelAvion(pivote2->Cola_Clientes);
                    pivote2->EstadoLleno=false;
                }
            }

            pivote2 = pivote2->siguiente;

        }while(pivote2!=NULL && pivote2!= pivote->fila->ultimo->siguiente);
        pivote = pivote->siguiente;
    }
}

#include "ListasEstaciones.h"

ListasEstaciones::ListasEstaciones()
{
    //ctor
}

ListasEstaciones::~ListasEstaciones()
{
    //dtor
}

void ListasEstaciones::AgregarEstaciones(Estaciones *Estacioness){

    Estaciones *Nodo_Estaciones = Estacioness;
    Nodo_Estaciones->id = this->id_actual;

    if(primero != NULL)
    {
        ultimo->siguiente = Nodo_Estaciones;
        Nodo_Estaciones->anterior = ultimo;
        primero->anterior = Nodo_Estaciones;
        Nodo_Estaciones->siguiente = primero;
        ultimo = Nodo_Estaciones;

    }
    else
    {
        primero = Nodo_Estaciones;
        ultimo = Nodo_Estaciones;

}
}
void ListasEstaciones::mostrar_datos(){
    Estaciones *aux = primero;

    do
    {

        if(aux->anterior != NULL)
        {
            cout<<"ANTERIOR ["<<aux->anterior->Nombre<<"]";
        }
        cout<<" - NODO ["<<aux->Nombre<<"]";
        if(aux->siguiente != NULL)
        {
            cout<<" - SIGUIENTE ["<<aux->siguiente->Nombre<<"]";
        }
        aux = aux->siguiente;

}while(aux != NULL && aux!= ultimo->siguiente);




}


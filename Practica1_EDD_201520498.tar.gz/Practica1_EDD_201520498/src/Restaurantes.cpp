#include "Restaurantes.h"

Restaurantes::Restaurantes()
{
    //ctor
}

Restaurantes::~Restaurantes()
{
    //dtor
}

Restaurantes::Restaurantes(int dato){

    this->capacidad=dato;

}

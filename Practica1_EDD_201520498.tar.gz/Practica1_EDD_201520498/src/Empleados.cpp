#include "Empleados.h"
#include <Empleados.h>


Empleados::Empleados()
{
    //ctor

}

Empleados::~Empleados()
{
    //dtor
}

Empleados::Empleados(int Id, int Turno, string Nombre, string Informacion, string Empleado_Ubicacion,int UbicacionEmpleado){
//int Id, int Turno, string Nombre, string Informacion, string Empleado_Ubicacion,int Tipo
        this->Id=Id;
        this->Turno=Turno;
        this->Nombre=Nombre;
        this->Informacion=Informacion;
        this->Empleado_Ubicacion=Empleado_Ubicacion;

              if(UbicacionEmpleado == 1)
            {
                EmpleadoenAtencion = true;
            }
                else
            {
                EmpleadoenSeguridad = true;
            }
}

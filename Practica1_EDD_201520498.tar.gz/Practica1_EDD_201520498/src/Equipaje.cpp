#include "Equipaje.h"
#include <Estaciones.h>
Equipaje::Equipaje()
{
    //ctor
}

Equipaje::~Equipaje()
{
    //dtor
}

Equipaje::Equipaje(int Id, string Informacion, string TipodeEquipaje, string AsuntodeEquipaje){
//int Id, string Informacion, string TipodeEquipaje, string AsuntodeEquipaje, int Estaciones
    this->Id=Id;
    this->Informacion=Informacion;
    this->TipodeEquipaje=TipodeEquipaje;
    this->AsuntodeEquipaje=AsuntodeEquipaje;
    this->Estaciones=Estaciones;
}

#include "Equipaje.h"
#include <Estaciones.h>
Equipaje::Equipaje()
{
    //ctor
}

Equipaje::~Equipaje()
{
    //dtor
}

Equipaje::Equipaje(int Id, string Ubicacion, string TipodeEquipaje, string AsuntodeEquipaje, int Esta){
//iint Id, string Ubicacion, string TipodeEquipaje, string AsuntodeEquipaje, int Esta
    this->Id=Id;
    this->TipodeEquipaje=TipodeEquipaje;
    this->AsuntodeEquipaje=AsuntodeEquipaje;
    if(Esta==1){

        Ingresando=true;
    }
}

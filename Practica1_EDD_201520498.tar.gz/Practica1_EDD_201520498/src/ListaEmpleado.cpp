#include "ListaEmpleado.h"
#include <Empleados.h>
#include <iostream>

using namespace std;
ListaEmpleado::ListaEmpleado()
{
    //ctor
}

ListaEmpleado::~ListaEmpleado()
{
    //dtor
}

void ListaEmpleado::AgregarEmpleados(Empleados *Empleadoss){

    Empleados *Nodo_Empleado = Empleadoss;
    Nodo_Empleado->Id =id_actual;

    if(primero!=NULL)
    {
        ultimo->Siguiente = Nodo_Empleado;
        Nodo_Empleado->Anterior = ultimo;
        ultimo = Nodo_Empleado;
    }
    else
    {
         primero = Nodo_Empleado;
         ultimo = Nodo_Empleado;
}
}

void ListaEmpleado::Mostrar_Datos(Empleados * Empleadoss){
 Empleados *aux = Empleadoss;
 cout<<"********Empleados*******\n";
cout <<aux->Id<<" Nombre: "<<aux->Nombre<<"\n Turno de Empleado: "<<aux->Turno<<"\n Genero:"<<aux->Informacion<<"\n";
}

int ListaEmpleado::Contador(){
    Empleados *aux = primero;
   int n =0 ;

   while(aux!=NULL)
   {
       n++;
       aux= aux->Siguiente;
   }

   return n;
}

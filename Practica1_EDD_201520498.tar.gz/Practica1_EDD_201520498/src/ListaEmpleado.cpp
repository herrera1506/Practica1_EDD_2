#include "ListaEmpleado.h"
#include <Empleados.h>
#include <iostream>

using namespace std;
ListaEmpleado::ListaEmpleado()
{
    //ctor
}

ListaEmpleado::~ListaEmpleado()
{
    //dtor
}

void ListaEmpleado::AgregarEmpleados(Empleados *Empleadoss){

    Empleados *Nodo_Empleado = Empleadoss;
    Nodo_Empleado->Id =id_actual;

    if(primero!=NULL)
    {
        ultimo->Siguiente = Nodo_Empleado;
        Nodo_Empleado->Anterior = ultimo;
        ultimo = Nodo_Empleado;
    }
    else
    {
         primero = Nodo_Empleado;
         ultimo = Nodo_Empleado;
}
}

void ListaEmpleado::mostrar_datos(){
    Empleados *aux = primero;

    while(aux != NULL)
    {
         cout <<aux->Id<<" -  Nombre: "<<aux->Nombre<<" -  Tipo de Empleado: "<<aux->Tipo<<"  \n | ";
          aux = aux->Siguiente;
}
}

void ListaEmpleado::Mostrar_Unidad(Empleados * Empleadoss){
 Empleados *aux = Empleadoss;
         cout <<aux->Id<<" -  Nombre: "<<aux->Nombre<<" -  Tipo de Empleado: "<<aux->Tipo<<"  \n | ";

}

#include "RamdonVuelos.h"
#include <Vuelos.h>
#include <stdlib.h>
#include <time.h>


RamdonVuelos::RamdonVuelos()
{
    //ctor
}

RamdonVuelos::~RamdonVuelos()
{
    //dtor
}

Vuelos * RamdonVuelos::Agregar_Vuelos(int datos){

int CantidadPasajeros = 0 + rand() % (1-25);
int CantidadEquipaje = 0 + rand() % (1-25);
int CantidadPaqueteria = 0 + rand() % (1-25);
int Situacion = 0 + rand() % (2-0);

string Situacionn ="";

string Nombre = "sin informacion";
int CantidadPasa = CantidadPasajeros;
int CantidadEquipo= CantidadEquipaje;
int CantidadPaque= CantidadPaqueteria;


Nombre = "Vuelo_0"+to_string(datos);

if (Situacion == 1){
    Situacionn =" Vuelo Entrado";

}
else {

    Situacionn =" Saliendo Vuelo";
}

                //int Id, string Nombre, int Cantidad_Pasajeros, int Cantidad_Equipajes, int Cantidad_Paquetes, int Entrando
Vuelos *NodoVueloRandom = new Vuelos(datos, Nombre ,CantidadPasa , CantidadEquipo , CantidadPaque,Situacion);

//Vuelos *NodoVueloRandom = new Vuelos(datos, Nombre ,CantidadPasa , CantidadEquipo , CantidadPaque,Situacionn);

return NodoVueloRandom;


}

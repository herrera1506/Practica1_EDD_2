#include "ColaEsperaEquipaje.h"
#include <Equipaje.h>
ColaEsperaEquipaje::ColaEsperaEquipaje()
{
    //ctor
}

ColaEsperaEquipaje::~ColaEsperaEquipaje()
{
    //dtor
}
void ColaEsperaEquipaje::AgregarEquipajeSala(Equipaje *Equipajee){

    Equipaje *Nodo_Equipaje = Equipajee;
    if(primero != NULL)
    {

        ultimo->Siguiente = Nodo_Equipaje;
        Nodo_Equipaje->Anterior = ultimo;
        ultimo = Nodo_Equipaje;

    }
    else
    {

        primero = Nodo_Equipaje;
        ultimo = Nodo_Equipaje;

}



}

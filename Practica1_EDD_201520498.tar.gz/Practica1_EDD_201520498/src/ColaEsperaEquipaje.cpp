#include "ColaEsperaEquipaje.h"
#include <Equipaje.h>

ColaEsperaEquipaje::ColaEsperaEquipaje()
{
    //ctor
}

ColaEsperaEquipaje::~ColaEsperaEquipaje()
{
    //dtor
}
void ColaEsperaEquipaje::AgregarEquipajeSala(Equipaje *Equipajee){

    Equipaje *Nodo_Equipaje = Equipajee;
    if(primero != NULL)
    {

        ultimo->Siguiente = Nodo_Equipaje;
        Nodo_Equipaje->Anterior = ultimo;
        ultimo = Nodo_Equipaje;

    }
    else
    {

        primero = Nodo_Equipaje;
        ultimo = Nodo_Equipaje;
}
}

void ColaEsperaEquipaje:: Push(string NombreEstacion){

     if(primero!=NULL)
        {
           if(primero->Siguiente==NULL)
           {

             cout<<" El Equipaje: "primero->nombre<<"paso a ser revisado y en unos momentos ya se podra retirar del Hangar"<<NombreEstacion<<"\n";
               primero = NULL;
               delete primero;


           }
           else
           {
             cout<<" El Equipaje"<<primero->nombre<<"paso a ser revisado y,  en unos momentos ya se podra retirar del Hangar"<<NombreEstacion<<"\n";
             Equipaje *temporal = primero;
             Equipaje *aux = temporal->Siguiente;
             aux->Anterior = NULL;
             primero = aux;
             delete temporal;
           }
        }
        else
        {
            cout<<" No hay equipajes para revision "<<endl;
        }
}

bool ColaEsperaEquipaje::Contiene(){
  Equipaje *aux = primero;
    int tiene = 0;
    while(aux!=NULL)
    {
        cout<<aux->id<<endl;
        tiene++;
        break;
        aux = aux->siguiente;
    }
    if(tiene>0)
    {
        return true;
    }
    else
    {
      return false;
    }
}

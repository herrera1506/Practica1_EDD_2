#include "ColaEsperaEquipaje.h"
#include <Equipaje.h>

ColaEsperaEquipaje::ColaEsperaEquipaje()
{
    //ctor
}

ColaEsperaEquipaje::~ColaEsperaEquipaje()
{
    //dtor
}
void ColaEsperaEquipaje::AgregarEquipajeSala(Equipaje *Equipajee){

    Equipaje *Nodo_Equipaje = Equipajee;
    if(primero != NULL)
    {

        ultimo->Siguiente = Nodo_Equipaje;
        Nodo_Equipaje->Anterior = ultimo;
        ultimo = Nodo_Equipaje;

    }
    else
    {

        primero = Nodo_Equipaje;
        ultimo = Nodo_Equipaje;
}
}

void ColaEsperaEquipaje:: Push(string NombreEstacion){

     if(primero!=NULL)
        {
           if(primero->Siguiente==NULL)
           {

             cout<<" El Equipaje: "<<primero->TipodeEquipaje<<"paso a ser reviado"<<NombreEstacion<<"\n";
               primero = NULL;
               delete primero;
           }
           else
           {
             cout<<" El Equipaje"<<primero->TipodeEquipaje<<"paso a ser revisado"<<NombreEstacion<<"\n";
             Equipaje *temporal = primero;
             Equipaje *aux = temporal->Siguiente;
             aux->Anterior = NULL;
             primero = aux;
             delete temporal;
           }
        }
        else
        {
            cout<<" No hay equipajes para revision "<<endl;
        }
}

bool ColaEsperaEquipaje::Contiene(){
  Equipaje *aux = primero;
    int tiene = 0;
    while(aux!=NULL)
    {
        cout<<aux->Id;
        tiene++;
        break;
        aux = aux->Siguiente;
    }
    if(tiene>0)
    {
        return true;
    }
    else
    {
      return false;
    }
}

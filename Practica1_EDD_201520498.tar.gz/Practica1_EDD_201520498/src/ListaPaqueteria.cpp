#include "ListaPaqueteria.h"
#include <Paqueteria.h>

ListaPaqueteria::ListaPaqueteria()
{
    //ctor
}

ListaPaqueteria::~ListaPaqueteria()
{
    //dtor
}

void ListaPaqueteria::AgregarPaquetes(Paqueteria *Paquete){

    Paqueteria * Nodo_Paquetes =Paquete;
    Nodo_Paquetes->id=Id_Actual;

     if (primero != NULL)
    {
     ultimo->Siguiente = Nodo_Paquetes;
     Nodo_Paquetes->Anterior = ultimo;
     ultimo = Nodo_Paquetes;
    }
    else {
        primero = Nodo_Paquetes;
        ultimo = Nodo_Paquetes;
    }
}

void ListaPaqueteria::MostrarDatos(Paqueteria * Pack){

    Paqueteria *aux= Pack;
     cout<<"\n Id: "<<aux->id <<"*************************Paquetes**********************\n";
        cout<<"\n Id: "<<aux->id <<"\n  Nombre:   "<<aux->Nombre<<"\n  Tipo de Paquete:  " <<aux-> TipoPaquete <<"\n  Asunto: "<<aux->Asunto<<"\n";


}

int ListaPaqueteria::Contar()
{
    Paqueteria *pivote = primero;
   int n =0 ;
   while(pivote!=NULL)
   {
       n++;
       pivote= pivote->Siguiente;
   }
   return n;
}

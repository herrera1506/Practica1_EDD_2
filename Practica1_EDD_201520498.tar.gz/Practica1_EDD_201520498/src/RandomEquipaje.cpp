#include "RandomEquipaje.h"
#include <Estaciones.h>
#include <stdlib.h>
#include <time.h>
#include <Equipaje.h>
#include <RandomClientes.h>

RandomEquipaje::RandomEquipaje()
{
    //ctor
}

RandomEquipaje::~RandomEquipaje()
{
    //dtor
}

Equipaje* RandomEquipaje::AgregarEquipajeRandom(int dato){

    int id=dato;
    int Tipo = 1 + rand() % (0-4);
    int Asutos = 0 +rand()% (4-0);//21por llegada y 1 por salir

        string Nombre_Equipaje ="Equipaje:";
        string TipoPaquete_Equipaje="";
        string Asunto_Equipaje="";

          if(Tipo == 4){
            TipoPaquete_Equipaje="Equipaje Personal";
        }
        else if (Tipo ==3){
            TipoPaquete_Equipaje="Equipaje Familiar";

        }
        else if (Tipo ==2){
            TipoPaquete_Equipaje="Equipaje Turistico";

        }
        else {
            TipoPaquete_Equipaje="Equipaje Comercial";

        }

        if(Asutos ==1 || Asutos == 2){

            Asunto_Equipaje="El Equipaje esta por llegada";
        }
        else{

             Asunto_Equipaje="El Equipaje esta por Salir";
        }

    //int Id, string Informacion, string TipodeEquipaje, string AsuntodeEquipaje, int Estaciones
         Equipaje *Random_Equipajess = new Equipaje(id,Nombre_Equipaje,TipoPaquete_Equipaje,Asunto_Equipaje);

        return Random_Equipajess;

}

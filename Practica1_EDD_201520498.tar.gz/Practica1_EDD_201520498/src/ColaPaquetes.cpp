#include "ColaPaquetes.h"

ColaPaquetes::ColaPaquetes()
{
    //ctor
}

ColaPaquetes::~ColaPaquetes()
{
    //dtor
}


void ColaPaquetes::AgregarColaPaquetes(Paqueteria *Paquete){
    Paqueteria *Nodo_Paquete = Paquete;
    if(primero != NULL)
    {
        ultimo->Siguiente = Nodo_Paquete;
        Nodo_Paquete->Anterior = ultimo;
        ultimo = Nodo_Paquete;

    }
    else
    {
        primero = Nodo_Paquete;
        ultimo = Nodo_Paquete;
}
}

void ColaPaquetes::PUSH(string NombreEstacion){
       if(primero!=NULL)
        {
           if(primero->siguiente==NULL)
           {
               cout<<" El Paquete: "<<primero->Nombre<<" paso a ser revisado y luego saldra por el Hangar"<<NombreEstacion<<"\n";
               primero = NULL;
               delete primero;
           }
           else
           {
             cout<<" El Paquete: "<<primero->Nombre<<" paso a ser revisado y luego saldra por el Hangar"<<NombreEstacion<<"\n";
             NodoPaqueteria *temp = primero;
             NodoPaqueteria *aux = temp->siguiente;
             aux->anterior = NULL;
             primero = aux;
             delete temp;
             }

        }
        else
        {
            cout<<" No hay Paquetes para revisar "<<endl;
        }
}

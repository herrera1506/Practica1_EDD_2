#include "ColaPaquetes.h"

ColaPaquetes::ColaPaquetes()
{
    //ctor
}

ColaPaquetes::~ColaPaquetes()
{
    //dtor
}


void ColaPaquetes::AgregarColaEquipaje(Paqueteria *Paquete){
    Paqueteria *Nodo_Paquete = Paquete;
    if(primero != NULL)
    {
        ultimo->Siguiente = Nodo_Paquete;
        Nodo_Paquete->Anterior = ultimo;
        ultimo = Nodo_Paquete;

    }
    else
    {
        primero = Nodo_Paquete;
        ultimo = Nodo_Paquete;
}

}

#include "Vuelos.h"

Vuelos::Vuelos()
{
    //ctor
}

Vuelos::~Vuelos()
{
    //dtor
}
Vuelos::Vuelos(int Id, string Nombre, int Cantidad_Pasajeros, int Cantidad_Equipajes, int Cantidad_Paquetes, int Entrando){

        this->id = Id;
        this->nombre=Nombre;
        this->Cantidad_Pasajeros = Cantidad_Pasajeros;
        this->Cantidad_Equipajes = Cantidad_Equipajes;
        this->Cantidad_Paquetes = Cantidad_Paquetes;
        this->Situacion_Vuelo=Situacion_Vuelo;

        if (Entrando ==1){

            SituacionVuelo = true;
            Informacion = "Ingreso por hangares";

            }
            else {
                Informacion = "Listo para ir al hangar";
                SituacionVuelo = false;
            }
}



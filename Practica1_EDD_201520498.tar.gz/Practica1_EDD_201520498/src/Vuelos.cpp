#include "Vuelos.h"

Vuelos::Vuelos()
{
    //ctor
}

Vuelos::~Vuelos()
{
    //dtor
}
Vuelos::Vuelos(int Id, string Nombre, int Cantidad_Pasajeros, int Cantidad_Equipajes, int Cantidad_Paquetes, string Situacion_Vuelo){

        this->id = Id;
        this->nombre=Nombre;
        this->Cantidad_Pasajeros = Cantidad_Pasajeros;
        this->Cantidad_Equipajes = Cantidad_Equipajes;
        this->Cantidad_Paquetes = Cantidad_Paquetes;
        this->Situacion_Vuelo=Situacion_Vuelo;
}



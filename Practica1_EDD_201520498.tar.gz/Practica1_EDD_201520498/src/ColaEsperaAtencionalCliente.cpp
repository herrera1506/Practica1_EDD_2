#include "ColaEsperaAtencionalCliente.h"
#include <Clientes.h>

ColaEsperaAtencionalCliente::ColaEsperaAtencionalCliente()
{
    //ctor
}

ColaEsperaAtencionalCliente::~ColaEsperaAtencionalCliente()
{
    //dtor
}

void ColaEsperaAtencionalCliente::AgregaralInicio(Clientes * Clientesss){

     Clientes *NuevoClienteEspera = Clientesss;

    if(primero!=NULL)
    {
        Clientes *aux = NuevoClienteEspera;
        aux->Siguiente = primero;
        aux->Siguiente->Anterior = aux;
        primero = aux;
    }
    else
    {
        primero=NuevoClienteEspera;
        ultimo =NuevoClienteEspera;
}
}

void ColaEsperaAtencionalCliente::AgregarClientesasala(Clientes * Clientess){

    Clientes *NodoEsperaCliente = Clientess;

    if(primero!=NULL)
    {
        ultimo->Siguiente= NodoEsperaCliente;
        NodoEsperaCliente->Anterior = ultimo;
        ultimo = NodoEsperaCliente;
  }
    else
    {
        primero=NodoEsperaCliente;
        ultimo =NodoEsperaCliente;


}


}

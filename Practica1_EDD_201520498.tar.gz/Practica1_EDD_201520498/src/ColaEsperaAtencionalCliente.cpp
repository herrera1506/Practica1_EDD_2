#include "ColaEsperaAtencionalCliente.h"
#include <Clientes.h>

ColaEsperaAtencionalCliente::ColaEsperaAtencionalCliente()
{
    //ctor
}

ColaEsperaAtencionalCliente::~ColaEsperaAtencionalCliente()
{
    //dtor
}

void ColaEsperaAtencionalCliente::AgregarAlInicio(Clientes * Clientesss){

     Clientes *NuevoClienteEspera = Clientesss;

    if(primero!=NULL)
    {
        Clientes *aux = NuevoClienteEspera;
        aux->Siguiente = primero;
        aux->Siguiente->Anterior = aux;
        primero = aux;
    }
    else
    {
        primero=NuevoClienteEspera;
        ultimo =NuevoClienteEspera;
}
}

void ColaEsperaAtencionalCliente::AgregarNormal(Clientes * Clientess){

    Clientes *NodoEsperaCliente = Clientess;

    if(primero!=NULL)
    {
        ultimo->Siguiente= NodoEsperaCliente;
        NodoEsperaCliente->Anterior = ultimo;
        ultimo = NodoEsperaCliente;
  }
    else
    {
        primero=NodoEsperaCliente;
        ultimo =NodoEsperaCliente;

}
}

int ColaEsperaAtencionalCliente::CantidaddePersona(){

    int No_Persona=0;
    Clientes *aux =primero;

    while(aux!=NULL)
    {
        No_Persona++;
        aux = aux->Siguiente;
    }
    return No_Persona;

}

void ColaEsperaAtencionalCliente::push_()
{
    Clientes *temp =primero;
    Clientes *aux = temp;
    if(temp!=NULL)
        {
           if(temp->Siguiente!=NULL && temp->Anterior!=NULL)
           {
             temp = temp->Siguiente;
             temp->Anterior = NULL;
             this->primero = temp;
             delete aux;
           }
           else
           {

               primero = NULL;
               delete primero;

           }
        }
}
Clientes* ColaEsperaAtencionalCliente::EnviarSiguiente()
{
  if(primero!=NULL)
    {
         return primero;
    }
    else
    {
        return NULL;
    }
}



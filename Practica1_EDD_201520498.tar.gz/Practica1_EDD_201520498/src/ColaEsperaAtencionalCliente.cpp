#include "ColaEsperaAtencionalCliente.h"
#include <Clientes.h>

ColaEsperaAtencionalCliente::ColaEsperaAtencionalCliente()
{
    //ctor
}

ColaEsperaAtencionalCliente::~ColaEsperaAtencionalCliente()
{
    //dtor
}

void ColaEsperaAtencionalCliente::AgregarAlInicio(Clientes * Clientesss){

     Clientes *NuevoClienteEspera = Clientesss;

    if(primero!=NULL)
    {
        Clientes *aux = NuevoClienteEspera;
        aux->Siguiente = primero;
        aux->Siguiente->Anterior = aux;
        primero = aux;
    }
    else
    {
        primero=NuevoClienteEspera;
        ultimo =NuevoClienteEspera;
}
}

void ColaEsperaAtencionalCliente::AgregarNormal(Clientes * Clientess){

    Clientes *NodoEsperaCliente = Clientess;

    if(primero!=NULL)
    {
        ultimo->Siguiente= NodoEsperaCliente;
        NodoEsperaCliente->Anterior = ultimo;
        ultimo = NodoEsperaCliente;
  }
    else
    {
        primero=NodoEsperaCliente;
        ultimo =NodoEsperaCliente;

}
}

int ColaEsperaAtencionalCliente::CantidaddePersona(){

    int No_Persona=0;
    Clientes *aux =primero;

    while(aux!=NULL)
    {
        No_Persona++;
        aux = aux->Siguiente;
    }
    return No_Persona;

}

void ColaEsperaAtencionalCliente::push_()
{
    Clientes *AEliminar =primero;

    Clientes *anterior = NULL;
    Clientes *aux;
    aux = AEliminar;

    if(AEliminar!=NULL)
    {
        if(AEliminar->Siguiente!=NULL)
        {

             AEliminar = AEliminar->Siguiente;
             AEliminar->Anterior = NULL;
             primero = AEliminar;
             delete aux;


        }
        else
        {
            if(AEliminar->Anterior==NULL)
            {
                primero = NULL;
                delete aux;
            }
    }

    }
    }

Clientes* ColaEsperaAtencionalCliente::EnviarSiguiente()
{
    return primero;
}



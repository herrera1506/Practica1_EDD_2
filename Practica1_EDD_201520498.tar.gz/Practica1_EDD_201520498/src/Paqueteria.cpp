#include "Paqueteria.h"

Paqueteria::Paqueteria()
{
    //ctor
}
Paqueteria::Paqueteria(int id, string Nombre, string TipoPaquete,string Asunto, int Esta){


    this->id=id;
    this->Nombre=Nombre;
    this->TipoPaquete=TipoPaquete;
    this->Asunto=Asunto;

  if (Esta==1){
        Ingresando=true;
  }
}

Paqueteria::~Paqueteria()
{
    //dtor
}


#include "Paqueteria.h"

Paqueteria::Paqueteria()
{
    //ctor
}
Paqueteria::Paqueteria(int id, string Nombre, string TipoPaquete,string Asunto, int Esta){


  if (Esta==1){
        Ingresando=true;
  }
}

Paqueteria::~Paqueteria()
{
    //dtor
}


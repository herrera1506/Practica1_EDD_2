#include "Clientes.h"

Clientes::Clientes()
{
    //ctor


}

Clientes::Clientes(string nombre, int Ordenamiento, int Edad, string Ubicacion,string TipoCliente, string Informacion,string Genero,int boleto){

    this->Nombre =nombre;
    this->Ordenamiento = Ordenamiento;
    this->Edad = Edad;
    this->Ubicacion=Ubicacion;
    this->TipoCliente=TipoCliente;
    this->Informacion =Informacion;
    this->Genero=Genero;

    if(boleto==1)
    {
        this->Boleto = true;
    }

    if(Ordenamiento==1)
    {
        this->discapacitado_ = true;
    }
    else if(Ordenamiento==2)
    {
        this->terecera_edad = true;

    }
    else if(Ordenamiento==3)
    {
        this->embarazada_ = true;
    }
    else if(Ordenamiento==4)
    {
        this->mayor_edad = true;
    }
    else
    {
        this->menor_edad = true;
    }

}

Clientes::~Clientes()
{
    //dtor
}

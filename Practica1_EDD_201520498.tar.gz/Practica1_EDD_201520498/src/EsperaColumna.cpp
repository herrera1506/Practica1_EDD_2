#include "EsperaColumna.h"

EsperaColumna::EsperaColumna()
{
    //ctor
}

EsperaColumna::~EsperaColumna()
{
    //dtor
}

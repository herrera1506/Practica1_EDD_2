#include "Graficar.h"
#include <fstream>
#include <ListaVuelos.h>
#include <Vuelos.h>
#include <ListaVuelos.h>
#include <iostream>
#include <Clientes.h>
#include <Empleados.h>
#include <string>
#include <ListaCliente.h>
#include <PilaEmpleado.h>
#include <RandomClientes.h>
#include <Paqueteria.h>
#include <RandomPaquetes.h>
#include <ListaPaqueteria.h>
#include <Equipaje.h>
#include <ListaEquipaje.h>
#include <RandomEquipaje.h>
#include <Vuelos.h>
#include <ListaVuelos.h>
#include <RamdonVuelos.h>
#include <ListaEmpleado.h>
#include <RandomEmpleado.h>
#include <Empleados.h>
#include <stdlib.h>
#include <time.h>
#include <ListaEmpleado.h>
#include <Hangares.h>
#include <Estaciones.h>
#include <ListasEstaciones.h>
#include <ListaHangares.h>
#include <Restaurantes.h>
#include <ListaRestaurantes.h>
#include <EsperaColumna.h>
#include <ListaFilaColumna.h>
#include <ListaRestaurantes.h>
#include <SaladeEspera.h>
#include <Graficar.h>



Graficar::Graficar()
{
    //ctor
}

Graficar::~Graficar()
{
    //dtor
}

void Graficar::GraficarVuelos(Vuelos* vuelosss){
    Vuelos *actual =new Vuelos();
    Vuelos *ax1= new Vuelos();
    actual=vuelosss;

     cout<<"Entra al metodo de Generar la imagen ";
     ofstream Grafica("nombre.txt");
      if (Grafica.fail()){
        cout<<"no se pudo crear la grafica";
    }
    else {
        Grafica<<"digraph G{";
        while (actual != NULL)
{
    Grafica<<actual->nombre<<"->"<<actual->Siguiente->nombre<<"; \n";
    actual->Siguiente;
}
    if(ax1 !=NULL){

        Grafica<<ax1->nombre;
    }
        Grafica<<"}";
        Grafica.flush();
        Grafica.close();
        cout<<"Se puedo Generar el archivo .dot \n";


}}

void Graficar::CrearGrafo(){

  GrafoCompleto = GrafoCompleto + "digraph{ \n size=\"16,6\"; ratio=fill; node[fontsize=24]; \n Nodo_0 [label=\"inicio\",color=blue,style=filled]; \n";
  AgregarListaEstacion();

}


void Graficar::AgregarListaEstacion(){
  Estaciones *pivote = LEstaciones->primero;

    do
    {
        GrafoCompleto = GrafoCompleto + "Nodo_0->"+pivote->Informacion+";\n";
        GrafoCompleto = GrafoCompleto + pivote->anterior->Nombre+"->"+pivote->Nombre+" ; \n"+pivote->Nombre+"->"+pivote->siguiente->Nombre+" ; \n ";
        pivote= pivote->siguiente;
    }while(pivote!=NULL && pivote!=LEstaciones->ultimo->siguiente);

    Restaurantes *Resta = LEstaciones->CrearResta->primero;

   // cout<<"Lista Restaurantes..."<<endl;
    while(Resta!=NULL)
    {
         GrafoCompleto = GrafoCompleto + "Nodo_0->Restaurante_"+ to_string(Resta->id)+ "; \n";

         if(Resta->anterior != NULL && Resta!=LEstaciones->CrearResta->primero)
        {
            GrafoCompleto = GrafoCompleto +"Restaurante_"+to_string(Resta->anterior->id)+"->";
            GrafoCompleto = GrafoCompleto+"Restaurante_"+to_string(Resta->id)+";";
        }

        if(Resta->siguiente!=NULL)
        {
            GrafoCompleto = GrafoCompleto + "Restaurante_"+ to_string(Resta->id)+ "->Restaurante_"+ to_string(Resta->siguiente->id) + "; \n";
        }
        Resta= Resta->siguiente;
    }
    Estaciones *pivote1 = LEstaciones->primero;
    do
    {
        if(pivote1->AtencionAlCliente1==true)
        {
            //AColaEsperaAtencion(pivote1);
            AAtencion(pivote1);
        }
        if(pivote1->SeguridadCliente1==true)
        {
            ASeguridad(pivote1);
        }
        pivote1= pivote1->siguiente;
    }while(pivote1!=NULL && pivote1!=LEstaciones->ultimo->siguiente);

    ARestaurantes();
    SalaDeEspera();
    GrafoCompleto= GrafoCompleto +"} \n";

}

void Graficar::AAtencion(Estaciones *Estacion){

    GrafoCompleto = GrafoCompleto + "subgraph \"cluster_Estacion_"+to_string(Estacion->id)+"\" { label=\""+Estacion->Nombre+" \"; \n";
    GrafoCompleto = GrafoCompleto + Estacion->Nombre;

    if(Estacion->ClientesEnEstaciones!=NULL)
    {
        GrafoCompleto = GrafoCompleto + "->"+Estacion->ClientesEnEstaciones->Nombre+";\n ";
        this->col = Estacion->ClientesEnEstaciones->Nombre;
    }
    else
    {
        GrafoCompleto = GrafoCompleto + "-> cola_atencion;\n ";
        this->col = "cola_atencion";
    }
    GrafoCompleto = GrafoCompleto + "}\n";

}

void Graficar:: AColaEsperaAtencion(string col ){

    Clientes *pivoclientes = LEstaciones->ColaEsperaAtencionC->primero;
    bool td = false;
    GrafoCompleto = GrafoCompleto + "subgraph \"cluster_Estacion_ColaEsperaAtencion\" { label=\"ColaEsperaAtencion\"; \n";

    while(pivoclientes!=NULL)
    {
        if(pivoclientes->Anterior!=NULL && pivoclientes!=NULL)
        {
            GrafoCompleto = GrafoCompleto +" "+ pivoclientes->Anterior->Nombre +"->"+pivoclientes->Nombre+";";
            td=true;
        }
        if(pivoclientes->Siguiente!=NULL && pivoclientes!=NULL)
        {
            GrafoCompleto = GrafoCompleto +" "+ pivoclientes->Nombre+"->"+pivoclientes->Siguiente->Nombre+"; \n";
            td=true;
        }

        pivoclientes = pivoclientes->Siguiente;
    }
    if(td == true)
    {
        GrafoCompleto = GrafoCompleto + col+"->"+LEstaciones->ColaEsperaAtencionC->primero->Nombre+"; \n";
    }
    else
    {
        GrafoCompleto = GrafoCompleto + col +"-> null_0;";
    }
    GrafoCompleto = GrafoCompleto + "}\n";
}

void Graficar::ASeguridad(Estaciones * Estacion){

    GrafoCompleto = GrafoCompleto + "subgraph \"cluster_Estacion_"+to_string(Estacion->id)+"\" { label=\""+Estacion->Nombre+"\"; \n";
    GrafoCompleto = GrafoCompleto + Estacion->Nombre;

    if(Estacion->ClientesEnEstaciones!=NULL)
    {

        GrafoCompleto = GrafoCompleto + "->"+Estacion->ClientesEnEstaciones->Nombre+";\n ";
        GrafoCompleto = GrafoCompleto + Estacion->Nombre+ "->struct1:f0;\n";
        col1 = Estacion->ClientesEnEstaciones->Nombre;
    }
    else
    {
        GrafoCompleto = GrafoCompleto + "-> CSeguridad;\n ";
        GrafoCompleto = GrafoCompleto + Estacion->Nombre+ "->struct1:f0;\n";
        col1 = "CSeguridad";
    }
    GrafoCompleto = GrafoCompleto + "}\n";
}

void Graficar::AColaSeguridad(string col ){

  Clientes *pivoclientes = LEstaciones->Colo_Espera->primero;
    bool td = false;
    GrafoCompleto = GrafoCompleto + "subgraph \"cluster_Estacion_ColaEsperaSeguridad\" { label=\"ColaEsperaSeguridad\"; \n";

    while(pivoclientes!=NULL)
    {
        if(pivoclientes->Anterior!=NULL && pivoclientes!=NULL)
        {
            GrafoCompleto = GrafoCompleto +" "+pivoclientes->Anterior->Nombre +"->"+pivoclientes->Nombre+";";
            td=true;
        }
        if(pivoclientes->Siguiente!=NULL && pivoclientes!=NULL)
        {
            GrafoCompleto = GrafoCompleto + " "+pivoclientes->Nombre+"->"+pivoclientes->Siguiente->Nombre+"; \n";
            td=true;
        }

        pivoclientes = pivoclientes->Siguiente;
    }
    if(td == true)
    {
        GrafoCompleto = GrafoCompleto + col+ "->" +LEstaciones->ColaEsperaAtencionC->primero->Nombre+ " ; \n";
    }
    else
    {
        GrafoCompleto = GrafoCompleto + col +"-> null_1;";
    }
    GrafoCompleto = GrafoCompleto + "}\n";
}


void Graficar::ARestaurantes(){
    Restaurantes *pivoclientes = LEstaciones->CrearResta->primero;

    cout<<"moviendose entre restaurantes"<<endl;
    while(pivoclientes!=NULL)
    {
        ARestaurant(pivoclientes);
        pivoclientes = pivoclientes->siguiente;
    }

}

void Graficar::ARestaurant(Restaurantes * restaurantess){

  bool td = false;
    Clientes *pivoclientes = restaurantess->cliente->primero;
    GrafoCompleto = GrafoCompleto + "subgraph \"cluster_restaurante_"+to_string(restaurantess->id)+"\" { label=\"Restaurante_"+to_string(restaurantess->id)+"\"; \n";

    while(pivoclientes!=NULL)
    {
        if(pivoclientes->Anterior!=NULL)
        {
            GrafoCompleto = GrafoCompleto + pivoclientes->Anterior->Nombre +"->"+pivoclientes->Nombre+";";
            td=true;
            break;
        }
        if(pivoclientes->Siguiente!=NULL)
        {
            GrafoCompleto = GrafoCompleto + pivoclientes->Nombre+"->"+pivoclientes->Siguiente->Nombre+"; \n";
            td=true;
            break;
        }

        pivoclientes = pivoclientes->Siguiente;
    }
    if(td == true)
    {
        GrafoCompleto = GrafoCompleto + col+"->"+restaurantess->cliente->primero->Nombre+"; \n";
    }
    else
    {
        GrafoCompleto = GrafoCompleto + col +"-> null_2;";
    }

    GrafoCompleto = GrafoCompleto + "}\n";

}

void Graficar::SalaDeEspera()
{
    ListaFilaColumna *pivote1 = LEstaciones->SalaEspera;
     EsperaColumna *pivote = pivote1->primero;
     GrafoCompleto = GrafoCompleto + "subgraph structs{\n node [shape=record]; \n";
     int n=1;
    while(pivote!=NULL)
    {
        SaladeEspera *pivote2 = pivote->fila->primero;
        int n1=0;
        GrafoCompleto = GrafoCompleto + "struct"+ to_string(n) +" [shape=record,label=\"<f"+ to_string(n1) +"> SalaEspera_"+ to_string(pivote2->Id) +"|";
        n1++;
        do
        {
            GrafoCompleto = GrafoCompleto + "|<f"+ to_string(n1) +"> SalaEspera_"+ to_string(pivote2->Id); +"|";
            n1++;
            pivote2 = pivote2->siguiente;
            if(pivote2==pivote->fila->ultimo->siguiente)
            {
                GrafoCompleto = GrafoCompleto +"\"\n";
            }

        }while(pivote2!=NULL && pivote2!= pivote->fila->ultimo->siguiente);
        GrafoCompleto = GrafoCompleto +"]; \n";
        n++;
        pivote = pivote->siguiente;

    }
    for(int a=1; a<(n+1);a++)
    {
        if((a+1)<(n))
        {
            GrafoCompleto = GrafoCompleto +"struct"+to_string(a)+":f0 -> struct"+to_string((a+1))+":f0; \n";
        }

    }
    GrafoCompleto = GrafoCompleto + "}\n";

}

void Graficar::hanga()
{
    Hangares *hang = LEstaciones->hangares->primero;
    GrafoCompleto = GrafoCompleto + "subgraph \"cluster_hangares\" { label=\"Hangares\"; \n";
    while(hang!=NULL)
    {
        if(hang->siguiente!=NULL && hang->Vueloss!=NULL && hang->siguiente->Vueloss!=NULL)
        {
            GrafoCompleto = GrafoCompleto + "Nodo_o->"+hang->Vueloss->nombre+";\n";
            GrafoCompleto = GrafoCompleto + hang->Vueloss->nombre +"->"+hang->siguiente->Vueloss->nombre+";\n";
        }

        hang = hang->siguiente;
    }
    GrafoCompleto = GrafoCompleto + "}\n";
}

void Graficar::Dot(){
    cout<<" CREANDO GRAFOS... "<<endl;
    CrearGrafo();

     ofstream fd2("GrafoCompleto.txt");
     fd2<<GrafoCompleto;
     fd2.flush();
     fd2.close();
     cout<<" GENERANDO IMAGEN "<<endl;
}

void Graficar::DotClientes(){

Gclientes = Gclientes + "digraph cluster{ \n node [style=filled]; \n";
if(LClientes->Id_Actual>0)
{
    if(LClientes->primero!=nullptr)
    {
        Clientes *clientes = LClientes->primero;
        int n=0;
   while(clientes!=nullptr)
    {
      if(n<LClientes->Id_Actual)
              {
                  Gclientes = Gclientes + clientes->Nombre+"->";
              }
              else
              {
                  //Gclientes = Gclientes +"null";
                  break;
              }
              n++;
      clientes = clientes->Siguiente;
    }
    Gclientes = Gclientes +"null";
    }

}

Gclientes = Gclientes +" Label = \"CLIENTES CREADOS\"; \n }";

     ofstream fd5("GrafoClientes.dot");
     fd5<<Gclientes;
     fd5.flush();
     fd5.close();
     cout<<" GENERANDO IMAGEN ";

}

void Graficar::DotVuelos(){
  GVuelo = GVuelo + "digraph cluster1{ \n node [style=filled]; \n";

    if(LVuelos->id_actual>0)
    {
        if(LVuelos->primero!=NULL)
        {
            Vuelos *vueos = LVuelos->primero;
            int n=0;
        while(vueos!=NULL)
            {
              if(n<LVuelos->id_actual)
              {
                  GVuelo = GVuelo + vueos->nombre+"->";
              }
              else
              {
                  GVuelo = GVuelo +"null";
                  break;
              }
              n++;
              vueos = vueos->Siguiente;
            }
        }

    }
    GVuelo = GVuelo +"null";

    GVuelo = GVuelo +" } \n ";

     ofstream fd3("GV.dot");
     fd3<<GVuelo;
     fd3.flush();
     fd3.close();
     cout<<" GENERANDO IMAGEN "<<endl;


}


void Graficar::DotSimulaciones(){
    GSim= GSim + "digraph G { \n";
    GSim = GSim + "size=\"20,6\"; ratio=fill; node[fontsize=24]; \n Aeropuerto_0; \n";

    cout<<"0";
    simula1();
    cout<<"1";
    simula2();
     cout<<"2";
    simula3();
     cout<<"3";
    simula4();
     cout<<"4";
     simula5();

    GSim = GSim +"}";

    ofstream fd4("GrafoSimulacion.dot");
     fd4<<GSim;
     fd4.flush();
     fd4.close();
     cout<<" GENERANDO IMAGEN "<<endl;
     }

void Graficar:: simula1(){

    if(LClientes->Id_Actual>0)
    {
if(LClientes->primero!=NULL)
{
    Clientes *clientes1 = this->LClientes->primero;
    GSim = GSim + "subgraph \"cluster1\" { \n node [style=filled]; \n";
int n=0;
    do
    {
        if(clientes1!=NULL)
        {

        if(n<LClientes->Id_Actual)
        {
            GSim = GSim + clientes1->Nombre+" [ label=\" Nombre: "+clientes1->Nombre+"\n Edad:"+to_string(clientes1->Edad)+" \n Tipo de Cliente: "+clientes1->TipoCliente+"\",style=filled]; \n";
        }
        else
        {
            break;
        }
        n++;


        }

      clientes1 = clientes1->Siguiente;
    }
    while(clientes1!=NULL);

    Clientes *clientes = this->LClientes->primero;
int n1=0;
    while(clientes!=NULL)
    {
        if(n1<LClientes->Id_Actual)
        {
             GSim = GSim +"Aeropuerto_0->"+clientes->Nombre+"; \n";
        }
        else
        {
            break;
        }
       n1++;
      clientes = clientes->Siguiente;

    }
    GSim = GSim +" }";
}
    }

}

void Graficar::simula2(){

if(LEmpleados->id_actual>0)
    {
if(LEmpleados->primero!=NULL)
{
     Empleados *emple = this->LEmpleados->primero;
      GSim = GSim + "subgraph \"cluster2\" { \n node [style=filled]; \n";
      int n=0;
   do
    {
        if(emple!=NULL)
        {
            if(n<LEmpleados->id_actual)
            {
               //GSim = GSim + emple->Nombre+" [ label=\" Nombre: "+emple->Nombre+"\n Genero:"+emple->Informacion+" \n Interaciones por Dia: "+to_string(emple->Turno)+"\",style=filled]; \n";
               //GSim = GSim + emple->Nombre+" [ label=\" Nombre: "+emple->Nombre+"\n Genero:"+emple->Informacion+"\",style=filled]; \n";
            GSim = GSim + emple->Nombre+" [ label=\" Nombre: "+emple->Nombre+"\n Genero:"+emple->Informacion+" \n Turnos por Dia: "+to_string(emple->Turno)+"\",style=filled]; \n";

            }
            else
            {

                break;

            }

                         n++;

        }
        emple = emple->Siguiente;
    } while(emple!=NULL);
    Empleados *emple1 =LEmpleados->primero;
int n1=0;
    while(emple1!=NULL)
    {
        if(n1<LEmpleados->id_actual)
        {
            GSim = GSim +"Aeropuerto_0->"+emple1->Nombre+"; \n";
        }
        else
        {
            break;
        }
        n1++;


      emple1 = emple1->Siguiente;
    }
    GSim = GSim +"}";
}
    }
    }


void Graficar::simula3(){

  if(LPaquetes->Id_Actual>0)
    {
        if(LPaquetes->primero!=NULL)
        {
            Paqueteria *paque =LPaquetes->primero;
      GSim = GSim + "subgraph \"cluster3\" { \n node [style=filled]; \n";
      int n=0;
    do
    {
        if(paque!=NULL)
        {
            if(n<LPaquetes->Id_Actual)
            {
                 GSim = GSim + paque->Nombre+" [ label=\" Nombre: "+paque->Nombre+"\n Tipo:"+paque->TipoPaquete+"\",style=filled]; \n";

            }
            else
            {
                break;
            }
            n++;

        }
        paque = paque->Siguiente;
    }while(paque!=NULL);
    Paqueteria *paque1 =LPaquetes->primero;

    int n1=0;
    while(paque1!=NULL)
    {
        if(n1<LPaquetes->Id_Actual)
        {
            GSim = GSim +"Aeropuerto_0->"+paque1->Nombre+"; \n";
        }
        else
        {
            break;
        }
        n1++;
      paque1 = paque1->Siguiente;
    }

    GSim = GSim +"}";
        }


    }
}

void Graficar::simula4(){

if(LEquipaje->Id_Actual>0)
    {
if(LEquipaje->primero!=NULL)
{
    Equipaje *equi = LEquipaje->primero;
      GSim = GSim + "subgraph \"cluster4\" { \n node [style=filled]; \n";
      int n=0;
    do
    {
        if(n<LEquipaje->Id_Actual)
        {
            if(equi!=NULL)
            {
                GSim = GSim + equi->AsuntodeEquipaje+" [ label=\" Id: "+equi->AsuntodeEquipaje+"\n Tipo:"+equi->TipodeEquipaje+"\",style=filled]; \n";
            }
        }
        else
        {
            break;
        }
        n++;

        equi = equi->Siguiente;
    }while(equi!=NULL);
    Equipaje *equi1 =LEquipaje->primero;

    int n1=0;
    while(equi1!=NULL)
    {
        if(n1<LEquipaje->Id_Actual)
        {
             GSim = GSim +"Aeropuerto_0->"+equi1->Ubicacion+"; \n";
        }

       else
        {
            break;
        }
        n++;
      equi1 = equi1->Siguiente;
    }

    GSim = GSim +" Label = \"EQUIPAJES CREADOS\"; \n }";
}

    }

}

void Graficar::simula5(){

 if(LVuelos->id_actual>0)
    {
        if(LVuelos->primero!=nullptr)
        {
            Vuelos *vuel = this->LVuelos->primero;
      GSim = GSim + "subgraph \"cluster5\" { \n node [style=filled]; \n";
int n =0;
      while(vuel!= nullptr)
      {
          if(n<LVuelos->id_actual)
          {

            GSim = GSim + vuel->nombre;
            GSim = GSim + " [ label=\" Nombre: "+vuel->nombre+"\n Capacidad Pasajeros:"+to_string(vuel->Cantidad_Pasajeros)+"\n Capacidad Paquetes:"+to_string(vuel->Cantidad_Paquetes)+"\n Capacidad Equipaje:"+to_string(vuel->Cantidad_Equipajes)+"\",style=filled]; \n";

            vuel = vuel->Siguiente;
          }
          else
          {
              break;
          }
           n++;
      }

    Vuelos *vuel1 = this->LVuelos->primero;
   int n1 =0;
    do
    {

        if(n1<LVuelos->id_actual)
        {
            if(vuel1!=nullptr)
            {
              GSim = GSim +"Aeropuerto_0->"+vuel1->nombre+"; \n";

            }
        }
        else
        {
            break;
        }

        n1++;

      vuel1 = vuel1->Siguiente;
    }
    while(vuel1!=nullptr);
    GSim = GSim +" }";
        }

    }

}

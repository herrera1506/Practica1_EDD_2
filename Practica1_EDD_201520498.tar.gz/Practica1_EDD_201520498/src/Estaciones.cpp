#include "Estaciones.h"

Estaciones::Estaciones()
{
    //ctor
}

Estaciones::~Estaciones()
{
    //dtor
}

Estaciones::Estaciones(int Id, string Nombre, string Informacion, int No_Estacion){

    this->Nombre = Nombre;
    this->Informacion = Informacion;

    if(No_Estacion == 1)
    {
        this->Atencion_alCliente = true;
    }
    else if(No_Estacion == 2)
    {
        this->seguridad_Cliente_inicio = true;
    }
    else
    {
        this->seguridad_Cliente_final = true;
}

}

#include "Estaciones.h"

Estaciones::Estaciones()
{
    //ctor
}

Estaciones::~Estaciones()
{
    //dtor
}

Estaciones::Estaciones(int Id, string Nombre, string Informacion, int No_Estacion){

    Nombre = Nombre;
    Informacion = Informacion;

    if(No_Estacion == 1)
    {
        AtencionAlCliente1 = true;
    }
    else if(No_Estacion == 2)
    {
        SeguridadCliente1 = true;
    }
    else
    {
        SeguridadCliente2 = true;
}

}

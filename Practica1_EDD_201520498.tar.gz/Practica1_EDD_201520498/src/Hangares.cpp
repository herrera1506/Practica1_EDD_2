#include "Hangares.h"


Hangares::Hangares()
{
    //ctor
}

Hangares::~Hangares()
{
    //dtor
}

Hangares::Hangares(string Nombre){
    this->Nombre=Nombre;
}

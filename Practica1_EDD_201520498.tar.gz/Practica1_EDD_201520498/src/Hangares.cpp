#include "Hangares.h"


Hangares::Hangares()
{
    //ctor
}

Hangares::~Hangares()
{
    //dtor
}

Hangares::Hangares(int Id, string Nombre){
    this->Id=Id;
    this->Nombre=Nombre;
}

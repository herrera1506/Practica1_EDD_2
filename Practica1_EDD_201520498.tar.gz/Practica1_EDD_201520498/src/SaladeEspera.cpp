#include "SaladeEspera.h"

SaladeEspera::SaladeEspera()
{
    //ctor
}

SaladeEspera::~SaladeEspera()
{
    //dtor
}

#include <iostream>
#include <Clientes.h>
#include <Empleados.h>
#include <string>
#include <ListaCliente.h>
#include <PilaEmpleado.h>
#include <RandomClientes.h>
#include <Paqueteria.h>
#include <RandomPaquetes.h>
#include <ListaPaqueteria.h>
#include <Equipaje.h>
#include <ListaEquipaje.h>
#include <RandomEquipaje.h>
#include <Vuelos.h>
#include <ListaVuelos.h>
#include <RamdonVuelos.h>
#include <ListaEmpleado.h>
#include <RandomEmpleado.h>
#include <Empleados.h>
#include <stdlib.h>
#include <time.h>
#include <ListaEmpleado.h>
#include <Hangares.h>
#include <Estaciones.h>
#include <ListasEstaciones.h>
#include <ListaHangares.h>
#include <Restaurantes.h>
#include <ListaRestaurantes.h>
#include <EsperaColumna.h>
#include <ListaFilaColumna.h>


using namespace std;

void Iniciar();
void IniciodeSimulacion();
void CrearUnidades();
//iniciar variables
void crearHangares();
void CrearEstaciones();
void CrearRestaurantes();
void CrearSaladeEsperaa();
//primer proceso
void EntradaP2(Clientes *cliente);
void EntradaP1(Clientes *cliente);
void Hangarr(Vuelos *vuelo);
void EntradaS1(Equipaje *equipaje);
void EntradaS2(Paqueteria *paquete);
void AreaEstaciones(Empleados *empleado);


int Interaciones = 0;
int AreadeAtencion = 0;
int AreadeSeguridad = 0;
int No_Hangares = 0;
int No_estaurantes = 0;
int No_Columnas = 0;
int No_Filas = 0;


Clientes *CrearClientesss;
ListaCliente *Lista_Cliente = new ListaCliente();

Equipaje *CrearEquipajeee;
ListaEquipaje *Lista_Equipaje = new ListaEquipaje();

Paqueteria *CrearPaquetesss;
ListaPaqueteria *Lista_Paqueteria = new ListaPaqueteria();

Vuelos *CrearVuelosss;
ListaVuelos *Lista_Vuelo = new ListaVuelos();

Empleados *CrearEmpleadoss;
ListaEmpleado *Lista_Empleado = new ListaEmpleado();

Estaciones *CrearEstacionesss;
ListasEstaciones *lista_estacion = new ListasEstaciones();

Hangares *CrearHangar;
ListaHangares *Lista_Hangares = new ListaHangares();

Restaurantes *CrearResta;
ListaRestaurantes *Lista_Restaurantes = new ListaRestaurantes();

EsperaColumna *Filacolumna;
ListaFilaColumna *filas = new ListaFilaColumna();

ColaEsperaAtencionalCliente *atencion_ = new ColaEsperaAtencionalCliente();

int main()
{

//cout<<" /////////////////////////////////////////////////////////////"<<endl;
//cout<<" ////***//////***//*******//***/////***////***////***/////////"<<endl;
//cout<<" ////***/*//*/***//*////////***/*///***////***////***/////////"<<endl;
//cout<<" ////***//*///***//*////////***//*//***////***////***/////////"<<endl;
//cout<<" ////***//////***//****/////***///*/***////***////***/////////"<<endl;
//cout<<" ////***//////***//*////////***/////***////***////***/////////"<<endl;
//cout<<" ////***//////***//*******//***/////***////**********/////////"<<endl;
//cout<<" /////////////////////////////////////////////////////////////"<<endl;

cout <<"***************************************************************************\n";
cout <<"*       ____                                                              *\n";
cout <<"*      \\  `.                                                             *\n";
cout <<"*        \\   `.                                                          *\n";
cout <<"*         \\    `.                                                        *\n";
cout <<"*          \\ EDD `.                                                      *\n";
cout <<"*          :. . . . `._______________________.-~|~~-._                    *\n";
cout <<"*           \                                 ---'-----`-._               *\n";
cout <<"*           /\"\"\"\"\"\"\"\"/  Simulacion _...---------..         ~-._________   *\n";
cout <<"*          //     .`_________  .-`           \ .-~           /            *\n";
cout <<"*         //    .'       ||__.~             .-~_____________/             *\n";
cout <<"*        //___.`           .~            .-~                              *\n";
cout <<"*                        .~           .-~                                 *\n";
cout <<"*                       .~         _.-~                                   *\n";
cout <<"*                       `-_____.-~'                                       *\n";
cout <<"***************************************************************************\n";
bool inciando = true;
       while(inciando ==true)
{
cout <<"*1- Iniciar Simulacion                                                    *\n";
cout <<"*2 - Salir                                                                *\n";
cout <<"***************************************************************************\n";
int opcion;
cin>>opcion;
cout<<"*****************************************************************************\n";
switch(opcion)
           {
           case 1:
            IniciodeSimulacion();
            break;
case 2:
cout<<"*****************************************************************************\n";
inciando = false;
break;
}

}
  return 0;

}

void IniciodeSimulacion(){

bool inciando = true;
cout<<" 1. Ingrese el numero de iteraciones que poseera la simulacion "<<endl;
cin>>Interaciones;
cout<<" 2. Ingrese el numero de puestos de atencion al cliente que existira en el sistema "<<endl;
cin>>AreadeAtencion;
cout<<" 3. Ingrese el numero de puestos de seguridad que existira en el sistema "<<endl;
cin>>AreadeSeguridad;
cout<<" 4. Ingrese el numero de Hangares  que poseera  el aeropuerto "<<endl;
cin>>No_Hangares;
cout<<" 5. Ingrese el numero de restaurantes  que poseera  el aeropuerto "<<endl;
cin>>No_estaurantes;
cout<<" 6. Ingrese el numero de sillas que poseeran las salas de esperas "<<endl;
cout<<"    Cantidad de Columnas:"<<endl;
cin>>No_Columnas;
cout<<"    Cantidad de Filas"<<endl;
cin>>No_Filas;

crearHangares();
CrearEstaciones();
CrearRestaurantes();
CrearSaladeEsperaa();
CrearUnidades();
}

void CrearUnidades()
{
int Rand1 = 1 + rand() % (5-0);

    if(Rand1 == 1)
    {
        RandomClientes *CracionCliente = new RandomClientes();
        CrearClientesss = CracionCliente->AgregarClientesRandom(Lista_Cliente->Id_Actual);
        Lista_Cliente->AgregarDatos2(CrearClientesss);
        Lista_Cliente->Id_Actual++;
        Lista_Cliente->MostrarDatos(CrearClientesss);

        if(CrearClientesss->Boleto == true)
        {
            CrearClientesss->Cliente_en_Seguridad = true;
            EntradaP1(CrearClientesss);
        }
        else
        {
            CrearClientesss->Cliente_en_Atencionalcliente = true;
            EntradaP2(CrearClientesss);
        }

    }
    else if(Rand1 == 2)
    {
        RandomEquipaje *CreacionEquipaje = new RandomEquipaje();
        CrearEquipajeee = CreacionEquipaje->AgregarEquipajeRandom(Lista_Equipaje->Id_Actual);
        Lista_Equipaje->AgregarEquipaje(CrearEquipajeee);
        Lista_Equipaje->Id_Actual++;
        Lista_Equipaje->MostrarDatos(CrearEquipajeee);
        if(CrearEquipajeee->AsuntodeEquipaje=="El Equipaje esta por llegada")
        {
            EntradaP2(CrearEquipajeee);
        }
        else
        {
             cout<<" \n El equipaje ["<<CrearEquipajeee->Informacion<<"] se ha transportado desde el hangar"<<endl;
        }

    }
    else if(Rand1 == 3)
    {
        RandomPaquetes *CreacionPaquetes = new RandomPaquetes();
        CrearPaquetesss = CreacionPaquetes->AgregarPaquetesRandom(Lista_Paqueteria->Id_Actual);
        Lista_Paqueteria->AgregarPaquetes(CrearPaquetesss);
        Lista_Paqueteria->Id_Actual++;
        Lista_Paqueteria->MostrarDatos(CrearPaquetesss);

        if(CrearPaquetesss->Asunto=="El paquete esta por llegada")
        {
            EntradaP2(CrearPaquetesss);
        }
        else
        {
             cout<<" \n El paquete ["<<CrearPaquetesss->Nombre<<"] se ha transportado desde el hangar \n";
        }

    }
    else if(Rand1 == 4)
    {
        RamdonVuelos *CreacionVuelos = new RamdonVuelos();
        CrearVuelosss = CreacionVuelos->Agregar_Vuelos(Lista_Vuelo->id_actual);
        Lista_Vuelo->Agregar_Vuelos(CrearVuelosss);
        Lista_Vuelo->id_actual++;
        Lista_Vuelo->mostrar_datos(CrearVuelosss);
        a_hangar(CrearVuelosss);////por aqui voy

    }
    else
    {
        empleadosAleatorios *nuevo = new empleadosAleatorios();
        empleado = nuevo->crearempleados(lista_empleado->id_actual);
        lista_empleado->ingresar_datos(empleado);
        lista_empleado->id_actual++;
        lista_empleado->mostrar_unidad(empleado);
        a_estaciones(empleado);

}

}

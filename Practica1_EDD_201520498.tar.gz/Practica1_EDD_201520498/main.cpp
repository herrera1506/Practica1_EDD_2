#include <iostream>
#include <Clientes.h>
#include <Empleados.h>
#include <string>
#include <ListaCliente.h>
#include <PilaEmpleado.h>
#include <RandomClientes.h>
#include <Paqueteria.h>
#include <RandomPaquetes.h>
#include <ListaPaqueteria.h>
#include <Equipaje.h>
#include <ListaEquipaje.h>
#include <RandomEquipaje.h>
#include <Vuelos.h>
#include <ListaVuelos.h>
#include <RamdonVuelos.h>
#include <ListaEmpleado.h>
#include <RandomEmpleado.h>
#include <Empleados.h>
#include <stdlib.h>
#include <time.h>
#include <ListaEmpleado.h>
#include <Hangares.h>
#include <Estaciones.h>
#include <ListasEstaciones.h>
#include <ListaHangares.h>
#include <Restaurantes.h>
#include <ListaRestaurantes.h>
#include <EsperaColumna.h>
#include <ListaFilaColumna.h>
#include <ListaRestaurantes.h>
#include <SaladeEspera.h>
#include <Graficar.h>

using namespace std;

void Iniciar();
void IniciodeSimulacion();
void CrearSimulacion();
void CrearUnies();

void CrearHangares();
void CrearEstaciones();
void CrearRestaurantes();
void CrearSaladeEsperaa();

void EntradaP2(Clientes *cliente);
void EntradaP1(Clientes *cliente);
void AsignacionHangar(Vuelos *vuelo);
void AsignacionEstaciones (Empleados * Esta);
void EntradaS1(Equipaje *equipaje);
void EntradaS2(Paqueteria *paquete);
void AreaEstaciones(Empleados *empleado);
void ActualizarColaEspera();
void VerificarEmpleados();
void ActualizarEstaciones();
void Historial();
void MenuGraficas();
void Grafica1();
void Grafica2();
void Grafica3();
void Grafica4();

int Interaciones = 0;
int AreadeAtencion = 0;
int AreadeSeguridad = 0;
int No_Hangares = 0;
int No_estaurantes = 0;
int No_Columnas = 0;
int No_Filas = 0;
bool ini = true;


Clientes *CrearClientesss;
ListaCliente *Lista_Cliente = new ListaCliente();

Equipaje *CrearEquipajeee;
ListaEquipaje *Lista_Equipaje = new ListaEquipaje();

Paqueteria *CrearPaquetesss;
ListaPaqueteria *Lista_Paqueteria = new ListaPaqueteria();

Vuelos *CrearVuelosss;
ListaVuelos *Lista_Vuelo = new ListaVuelos();

Empleados *CrearEmpleadoss;
ListaEmpleado *Lista_Empleado = new ListaEmpleado();

Estaciones *CrearEstacionesss;
ListasEstaciones *lista_estacion = new ListasEstaciones();

Hangares *CrearHangar;
ListaHangares *Lista_Hangares = new ListaHangares();

Restaurantes *CrearResta;
ListaRestaurantes *Lista_Restaurantes = new ListaRestaurantes();

EsperaColumna *filaespera_;
ListaFilaColumna *filas = new ListaFilaColumna();


ColaEsperaAtencionalCliente *atencion_ = new ColaEsperaAtencionalCliente();
Graficar *grafo = new Graficar();

int main()
{
cout <<"***************************************************************************\n";
cout <<"*       ____                                                              *\n";
cout <<"*      \\  `.                                                             *\n";
cout <<"*        \\   `.                                                          *\n";
cout <<"*         \\    `.                                                        *\n";
cout <<"*          \\ EDD `.                                                      *\n";
cout <<"*          :. . . . `._______________________.-~|~~-._                    *\n";
cout <<"*           \                                 ---'-----`-._               *\n";
cout <<"*           /\"\"\"\"\"\"\"\"/  Simulacion _...---------..         ~-._________   *\n";
cout <<"*          //     .`_________  .-`           \ .-~           /            *\n";
cout <<"*         //    .'       ||__.~             .-~_____________/             *\n";
cout <<"*        //___.`           .~            .-~                              *\n";
cout <<"*                        .~           .-~                                 *\n";
cout <<"*                       .~         _.-~                                   *\n";
cout <<"*                       `-_____.-~'                                       *\n";
cout <<"***************************************************************************\n";
bool ini = true;
       while(ini ==true)
{
cout <<"*1- Iniciar Simulacion                                                    *\n";
cout <<"*2- Graficas                                                              *\n";
cout <<"*3- Salir                                                                *\n";
cout <<"***************************************************************************\n";
int opcion;
cin>>opcion;
cout<<"*****************************************************************************\n";
switch(opcion)
           {
           case 1:
            IniciodeSimulacion();
            break;
            case 2:
            MenuGraficas();
            break;
            case 3:
            ini = false;
            break;
}
}
  return 0;
}

void IniciodeSimulacion(){

bool inciando = true;
cout<<" 1. Ingrese el numero de iteraciones \n";
cin>>Interaciones;
cout<<" 2. Ingrese el numero de puestos de atencion al cliente \n";
cin>>AreadeAtencion;
cout<<" 3. Ingrese el numero de puestos de seguridad \n";
cin>>AreadeSeguridad;
cout<<" 4. Ingrese el numero de Hangares \n";
cin>>No_Hangares;
cout<<" 5. Ingrese el numero de restaurantes\n";
cin>>No_estaurantes;
cout<<" 6. Ingrese el numero de sillas\n";
cout<<"    Cantidad de Columnas: \n";
cin>>No_Columnas;
cout<<"    Cantidad de Filas \n";
cin>>No_Filas;


CrearEstaciones();
CrearRestaurantes();
CrearSaladeEsperaa();
CrearUnies();

}

void CrearUnies()
{
int j =0;

while(j<Interaciones){

        cout<<"******************************Interaciones No."<<j<<"***************************\n";
        CrearSimulacion();
        cout<<"*******************************************************************************\n";
        ActualizarColaEspera();
        VerificarEmpleados();
        ActualizarEstaciones();
        cout<<"*******************************Fin de Simulacion********************************\n";
        Historial();

        j++;
}
}

void CrearSimulacion(){

  int Uni = 1 + rand() % (5-0);

    if(Uni == 1)
    {
        RandomClientes *nuevo = new RandomClientes();
        CrearClientesss = nuevo->AgregarClientesRandom(Lista_Cliente->Id_Actual);
        Lista_Cliente->AgregarDatos2(CrearClientesss);
        Lista_Cliente->Id_Actual++;
        Lista_Cliente->MostrarDatos2(CrearClientesss);

        if(CrearClientesss->Tiempo_Vuelo == true)
        {
            CrearClientesss->Cliente_en_Seguridad = true;
            EntradaP1(CrearClientesss);
        }
        else
        {
            CrearClientesss->Cliente_en_Atencionalcliente = true;
            EntradaP1(CrearClientesss);
        }

    }
   else if(Uni == 2)
    {
        RandomEquipaje *nuevo = new RandomEquipaje();
        CrearEquipajeee = nuevo->AgregarEquipajeRandom(Lista_Equipaje->Id_Actual);
        Lista_Equipaje->AgregarEquipaje(CrearEquipajeee);
        Lista_Equipaje->Id_Actual++;
        Lista_Equipaje->MostrarDatos(CrearEquipajeee);

        if(CrearEquipajeee->Ingresando==false)
        {
            EntradaS1(CrearEquipajeee);
        }
        else
        {
             cout<<"* El equipaje "<<CrearEquipajeee->AsuntodeEquipaje<<" se ha transportado desde el hangar *\n";
        }

    }

    else if(Uni == 3)
    {
        RandomPaquetes *nuevo = new RandomPaquetes();
        CrearPaquetesss = nuevo->AgregarPaquetesRandom(Lista_Paqueteria->Id_Actual);
        Lista_Paqueteria->AgregarPaquetes(CrearPaquetesss);
        Lista_Paqueteria->Id_Actual++;
        Lista_Paqueteria->MostrarDatos(CrearPaquetesss);

        if(CrearPaquetesss->Ingresando==false)
        {
            EntradaS2(CrearPaquetesss);
        }
        else
        {
             cout<<"* El paquete "<<CrearClientesss->Nombre<<" se ha transportado \n";
        }

    }

    else if(Uni == 4)
    {
        RamdonVuelos *nuevo = new RamdonVuelos();
        CrearVuelosss = nuevo->Agregar_Vuelos(Lista_Vuelo->id_actual);
        Lista_Vuelo->Agregar_Vuelos(CrearVuelosss);
        Lista_Vuelo->id_actual++;

        Lista_Vuelo->mostrar_datos(CrearVuelosss);

        AsignacionHangar(CrearVuelosss);

    }
    else
    {
        RandomEmpleado *nuevo = new RandomEmpleado();
        CrearEmpleadoss = nuevo->AgregarEmpleadoRandom(Lista_Empleado->id_actual);
        Lista_Empleado->AgregarEmpleados(CrearEmpleadoss);
        Lista_Empleado->id_actual++;
        Lista_Empleado->Mostrar_Datos(CrearEmpleadoss);
        AsignacionEstaciones(CrearEmpleadoss);
    }
}


void CrearHangares()
{
    for(int n = 1; n<(No_Hangares+1);n++)
    {
        CrearHangar = new Hangares("Hangar_"+to_string(Lista_Hangares->id_actual));
        Lista_Hangares->AgregarHangarares(CrearHangar);
        Lista_Hangares->id_actual++;
    }
}

void CrearEstaciones()
{
    for(int n=1; n<(AreadeAtencion+1);n++)
    {
        //int id, string Nombre, string Informacion, int No_Estacion
        CrearEstacionesss = new Estaciones (n,"Estacion_Atencion_"+to_string(lista_estacion->id_actual),"Atencion al Cliente", 1);
        lista_estacion->AgregarEstacion(CrearEstacionesss);
        lista_estacion->id_actual++;
    }
    for(int n = 1; n<(AreadeSeguridad+1);n++)
    {
        CrearEstacionesss = new Estaciones (n,"Estacion_Seguridad_"+to_string(lista_estacion->id_actual),"Seguridad entrada", 2);
        lista_estacion->AgregarEstacion(CrearEstacionesss);
        lista_estacion->id_actual++;
    }
}

void CrearRestaurantes()
{
        for(int n=1; n<(No_estaurantes+1);n++)
            {
        int capacidad = 15 + rand() % (35-10);
        CrearResta = new Restaurantes(capacidad);
        Lista_Restaurantes->Agregar_Restaurantes(CrearResta);
        Lista_Restaurantes->id_actual++;
            }
        lista_estacion->CrearResta = Lista_Restaurantes;
}

void CrearSaladeEsperaa(){
    for(int a=0; a<(No_Filas+1); a++)
    {
        filaespera_ = new EsperaColumna();
        SaladeEspera *columnassalaespera;
        ListaFilaColumna *columnas = new ListaFilaColumna();
        ListaSaladeEspera * col =new ListaSaladeEspera();

        for(int b=0;b<(No_Columnas+1);b++)
        {
            columnassalaespera = new SaladeEspera();
            col->Agregar_Espera(columnassalaespera);
            col->id_actual++;
        }

        filaespera_->fila = col;
        filas->AgregarAsientos(filaespera_);
        filas->id_actual++;
    }

    lista_estacion->SalaEspera = filas;
}


void EntradaP1(Clientes *Atencion){

    bool entro  = lista_estacion->AsignacionestacionAtencion(Atencion);
    if(entro == true)
    {
    }
    else
    {
         cout<<"El Cliente: "<<Atencion->Nombre<<"] ingreso a la cola de Espera \n";

         if(Atencion->embarazada_==true || Atencion->discapacitado_ ==true || Atencion->terecera_edad==true)
         {
            lista_estacion->ColaEsperaAtencionC->AgregarAlInicio(Atencion);
            lista_estacion->ColaEsperaAtencionC->id_actual++;
            lista_estacion->ColaEsperaAtencionC->actual++;

            cout<<" Adelante: "<<Atencion->Informacion<<"Ventanilla Especial";
         }
         else
         {
            lista_estacion->ColaEsperaAtencionC->AgregarNormal(Atencion);
            lista_estacion->ColaEsperaAtencionC->id_actual++;
            lista_estacion->ColaEsperaAtencionC->actual++;

         }
}

}

void EntradaP2(Clientes *seguridad){

    bool intros = lista_estacion->AsignacionesestacionSeguridad(seguridad);
    if(intros==true)
    {
         cout<<"Cliente: "<<seguridad->Nombre<<" esta en estacion de seguridad \n";
    }
    else
      {
         cout<<"Cliente: "<<seguridad->Nombre<<"] ingreso a la cola de Espera\n";

         if(seguridad->embarazada_==true || seguridad->discapacitado_ ==true || seguridad->terecera_edad==true)
         {
            lista_estacion->Colo_Espera->AgregarAlInicio(seguridad);
            lista_estacion->Colo_Espera->id_actual++;
            lista_estacion->Colo_Espera->actual++;

            cout<<"Adelante: ["<<seguridad->Informacion<<"Ventanilla Especial \n";
         }
         else
         {
            lista_estacion->Colo_Espera->AgregarNormal(seguridad);
            lista_estacion->Colo_Espera->id_actual++;
            lista_estacion->Colo_Espera->actual++;

         }
    }

}

void AsignacionHangar(Vuelos * vuelo){
    bool ingresando = lista_estacion->hangares->AgregarVuelo(vuelo);
    if(ingresando == true)
    {
        cout<<"El vuelo: "<<vuelo->nombre<<"fue asignado a un hangar \n";
    }
    else
    {
        cout<<"vuelo ["<<vuelo->nombre<<"] no encontro hangar y se retiro \n";
    }
}

void EntradaS1(Equipaje *equipaje)
{
    bool ingrea = lista_estacion->AsignacionestacionSeguridad1(equipaje);
    if(ingrea == true)
    {
        cout<<"equipaje: "<<equipaje->TipodeEquipaje<<"] entro a la cola para revision \n";
    }
}

void EntradaS2(Paqueteria *paqueteria){
    bool ingrea = lista_estacion->AsignacionestacionSeguridad2(paqueteria);
    if(ingrea == true)
    {
        cout<<"El paquete:"<<paqueteria->Nombre<<" entro a la cola para revision \n";
    }
}

void AsignacionEstaciones(Empleados *empleado){
    bool ingresando = lista_estacion->AgregandoEmpleados(empleado);
    if(ingresando == true)
    {
        cout<<"empleado: "<<empleado->Nombre<<"fue asignado a una estacion"+empleado->Empleado_Ubicacion;
    }
    else
    {
    cout<<"El empleado "<<empleado->Nombre<<"no disponible \n";
    }
}

void ActualizarColaEspera(){
        cout<<"****************************Atencion Al Cliente**********************************\n";
        cout<<"*No.Personas Atendidas "<<lista_estacion->ColaEsperaAtencionC->id_actual<<"     *\n";
        cout<<"****************************Atencion de Seguridad********************************\n";
        cout<<"*No. Personas Atendidas"<<lista_estacion->Colo_Espera->id_actual<<" personas*****\n";
}


void VerificarEmpleados(){

        int empleado = lista_estacion->EncontrarE();
        cout<<"* Hay al menos "<<empleado<<" empleados trabajando en las estaciones *\n";

}

void ActualizarEstaciones(){

 cout<<"*******************************ESTACIONES DE ATENCION*********************************\n";
 lista_estacion->ActualizarEA();// o puede ser la otra
 cout<<" \n";
 lista_estacion->AdquirirEA();
 cout<<" \n";

 cout<<"********************************ESTACIONES DE SEGURIDAD********************************\n";
 lista_estacion->ActualizarES();
  cout<<" \n";
 lista_estacion->AdquirirEstadoSeguridad();
  cout<<" \n";
 lista_estacion->EliminarSeguridad2();
  cout<<" \n";
 lista_estacion->EliminarSeguridad3();
  cout<<" \n";
 cout<<"**************************************Restaurantes*************************************\n";
 lista_estacion->ReducirenRestaurantes();
 cout<<"*************************************SALA DE ESPERA************************************\n";
 lista_estacion->ReducirSaLasdeEspera();
cout<<" \n";

}

void Historial(){
    cout<<"**********************************HISTORIAL*****************************************\n";
    cout<<"*Total: "<<Lista_Cliente->Id_Actual<<"Personas                                     *\n";
    cout<<"*Total: "<<Lista_Empleado->id_actual<<"Empleados                                   *\n";
    cout<<"*Total: "<<Lista_Equipaje->Id_Actual<<"Equipajes                                   *\n";
    cout<<"*Total: "<<Lista_Paqueteria->Id_Actual<<" Paquetes                                 *\n";
    cout<<"*Total: "<<Lista_Vuelo->id_actual<<" Vuelos                                        *\n";
    cout<<"*Total: "<<lista_estacion->PerdieronSuvuelodeRestaurantes<<" perdieron su vuelo Restaurantes *\n";
    cout<<"*Total: "<<lista_estacion->PerdieronSuvuelodeSaladeEspera<<" perdieron su vuelo Sala de Espera *\n";
    cout<<"**********************************HISTORIAL RESTAURANTE*****************************\n";
    cout<<"*Entraron "<<lista_estacion->PesonasRestau<<" personas a los restaurantes          *\n";
    cout<<"*******************************HISTORIAL SALA DE ESPERA*****************************\n";
    cout<<" Entraron "<<lista_estacion->PersonasEnSalaEspera<<" personas a la Sala de Espera  *\n"<<endl;
    cout<<" Un total de "<<lista_estacion->PersonasSalieronAlAvion<<" abordaron su vuelo      *\n"<<endl;
    cout<<" Un total de "<<lista_estacion->AvionesQueDespegaron<<" vuelos salieron del aeropuerto *\n"<<endl;
    cout<<"************************************************************************************\n";

}

void MenuGraficas(){
    bool Emp = true;
       while(Emp ==true)
       {
cout<<" /////////////////////////////////////////////////////////////";
cout<<" ////***//////***//*******//***/////***////***////***/////////";
cout<<" ////***/*//*/***//*////////***/*///***////***////***/////////";
cout<<" ////***//*///***//*////////***//*//***////***////***/////////";
cout<<" ////***//////***//****/////***///*/***////***////***/////////";
cout<<" ////***//////***//*////////***/////***////***////***/////////";
cout<<" ////***//////***//*******//***/////***////**********/////////";
cout<<" /////////////////////////////////////////////////////////////";

cout<<"//// 1-. Grafica General                                       ";
cout<<"//// 2-. Grafica Clientes                                      ";
cout<<"//// 3-. Grafica Vuelos                                        ";
cout<<"//// 4-. Grafica Simulacion                                    ";
int opcionReporte=0;
cin>>opcionReporte;

switch(opcionReporte){
            case 1:
                Grafica1();
                Emp=false;
                break;
            case 2:
                Grafica2();
                Emp=false;
                break;
            case 3:
                Grafica4();
                Emp=false;
                break;
            case 4:
                Grafica3();
                Emp=false;
                break;
            case 5:
                Emp=false;
                break;
}

}}

void Grafica1(){
    grafo= new Graficar();
    grafo->LEstaciones =lista_estacion;
    grafo->Dot();
    system("dot -Tpng GrafoCompleto.dot -o GrafoCompleto.png");

}

void Grafica2(){
    grafo= new Graficar();
    grafo->LClientes =Lista_Cliente;
    grafo->DotClientes();
    system("dot -Tpng GrafoClientes.dot -o GrafoClientes.png");
}

void Grafica3(){
    grafo = new Graficar();
    grafo->LClientes=Lista_Cliente;
    grafo->LEmpleados=Lista_Empleado;
    grafo->LEquipaje=Lista_Equipaje;
    grafo->LVuelos=Lista_Vuelo;
    grafo->LPaquetes=Lista_Paqueteria;
    grafo->DotSimulaciones();
    system("dot -Tpng GrafoSimulacion.dot -o GrafoSimulaciones.png");
}

void Grafica4(){

    grafo= new Graficar();
    grafo->LVuelos =Lista_Vuelo;
    grafo->DotVuelos();
    system("dot -Tpng GV.dot -o GrafoVuelos.png");

}
